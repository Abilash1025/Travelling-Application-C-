﻿namespace WindowsFormsApplication2
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.label1 = new System.Windows.Forms.Label();
            this.extbtn = new System.Windows.Forms.Button();
            this.srchbtn = new System.Windows.Forms.Button();
            this.dltbtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.savebtn = new System.Windows.Forms.Button();
            this.lbldayid = new System.Windows.Forms.Label();
            this.lblvehicle = new System.Windows.Forms.Label();
            this.lblpckge = new System.Windows.Forms.Label();
            this.lblstrttym = new System.Windows.Forms.Label();
            this.lblendtym = new System.Windows.Forms.Label();
            this.lblstrtkm = new System.Windows.Forms.Label();
            this.lblendkm = new System.Windows.Forms.Label();
            this.lbltourchrge = new System.Windows.Forms.Label();
            this.lblextrakmchrge = new System.Windows.Forms.Label();
            this.lblwaitngchrge = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncalculate = new System.Windows.Forms.Button();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txtextrkmfullchrge = new System.Windows.Forms.TextBox();
            this.txtwaitingfullchrge = new System.Windows.Forms.TextBox();
            this.txttourchrge = new System.Windows.Forms.TextBox();
            this.txtbxdayrentid = new System.Windows.Forms.TextBox();
            this.txtstrtrdng = new System.Windows.Forms.TextBox();
            this.txtendrdng = new System.Windows.Forms.TextBox();
            this.cmbvehcl = new System.Windows.Forms.ComboBox();
            this.cmbpack = new System.Windows.Forms.ComboBox();
            this.btnhme = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.txtbxcustomer = new System.Windows.Forms.TextBox();
            this.lblnmber = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.dtpstart = new System.Windows.Forms.DateTimePicker();
            this.dtpend = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnview = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(540, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Day Tour";
            // 
            // extbtn
            // 
            this.extbtn.BackColor = System.Drawing.Color.DarkRed;
            this.extbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.extbtn.Location = new System.Drawing.Point(1090, 746);
            this.extbtn.Name = "extbtn";
            this.extbtn.Size = new System.Drawing.Size(111, 40);
            this.extbtn.TabIndex = 8;
            this.extbtn.Text = "Exit";
            this.extbtn.UseVisualStyleBackColor = false;
            this.extbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // srchbtn
            // 
            this.srchbtn.BackColor = System.Drawing.Color.DarkRed;
            this.srchbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.srchbtn.Location = new System.Drawing.Point(449, 737);
            this.srchbtn.Name = "srchbtn";
            this.srchbtn.Size = new System.Drawing.Size(112, 40);
            this.srchbtn.TabIndex = 6;
            this.srchbtn.Text = "Search";
            this.srchbtn.UseVisualStyleBackColor = false;
            this.srchbtn.Click += new System.EventHandler(this.srchbtn_Click);
            // 
            // dltbtn
            // 
            this.dltbtn.BackColor = System.Drawing.Color.DarkRed;
            this.dltbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dltbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.dltbtn.Location = new System.Drawing.Point(309, 737);
            this.dltbtn.Name = "dltbtn";
            this.dltbtn.Size = new System.Drawing.Size(112, 40);
            this.dltbtn.TabIndex = 5;
            this.dltbtn.Text = "Delete";
            this.dltbtn.UseVisualStyleBackColor = false;
            this.dltbtn.Click += new System.EventHandler(this.dltbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.DarkRed;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.updatebtn.Location = new System.Drawing.Point(173, 737);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(112, 40);
            this.updatebtn.TabIndex = 4;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = false;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // savebtn
            // 
            this.savebtn.BackColor = System.Drawing.Color.DarkRed;
            this.savebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.savebtn.Location = new System.Drawing.Point(29, 737);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(112, 40);
            this.savebtn.TabIndex = 3;
            this.savebtn.Text = "Save";
            this.savebtn.UseVisualStyleBackColor = false;
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // lbldayid
            // 
            this.lbldayid.AutoSize = true;
            this.lbldayid.BackColor = System.Drawing.Color.Transparent;
            this.lbldayid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbldayid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldayid.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldayid.Location = new System.Drawing.Point(38, 83);
            this.lbldayid.Name = "lbldayid";
            this.lbldayid.Size = new System.Drawing.Size(125, 24);
            this.lbldayid.TabIndex = 38;
            this.lbldayid.Text = "Day_Tour_ID";
            // 
            // lblvehicle
            // 
            this.lblvehicle.AutoSize = true;
            this.lblvehicle.BackColor = System.Drawing.Color.Transparent;
            this.lblvehicle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblvehicle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehicle.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblvehicle.Location = new System.Drawing.Point(38, 331);
            this.lblvehicle.Name = "lblvehicle";
            this.lblvehicle.Size = new System.Drawing.Size(146, 24);
            this.lblvehicle.TabIndex = 39;
            this.lblvehicle.Text = "Rent_Vehicle_Id";
            // 
            // lblpckge
            // 
            this.lblpckge.AutoSize = true;
            this.lblpckge.BackColor = System.Drawing.Color.Transparent;
            this.lblpckge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpckge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpckge.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblpckge.Location = new System.Drawing.Point(38, 381);
            this.lblpckge.Name = "lblpckge";
            this.lblpckge.Size = new System.Drawing.Size(91, 24);
            this.lblpckge.TabIndex = 40;
            this.lblpckge.Text = "Packages";
            // 
            // lblstrttym
            // 
            this.lblstrttym.AutoSize = true;
            this.lblstrttym.BackColor = System.Drawing.Color.Transparent;
            this.lblstrttym.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblstrttym.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstrttym.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblstrttym.Location = new System.Drawing.Point(39, 437);
            this.lblstrttym.Name = "lblstrttym";
            this.lblstrttym.Size = new System.Drawing.Size(154, 24);
            this.lblstrttym.TabIndex = 41;
            this.lblstrttym.Text = "Tour_Start_Time";
            // 
            // lblendtym
            // 
            this.lblendtym.AutoSize = true;
            this.lblendtym.BackColor = System.Drawing.Color.Transparent;
            this.lblendtym.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblendtym.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblendtym.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblendtym.Location = new System.Drawing.Point(39, 488);
            this.lblendtym.Name = "lblendtym";
            this.lblendtym.Size = new System.Drawing.Size(148, 24);
            this.lblendtym.TabIndex = 42;
            this.lblendtym.Text = "Tour_End_TIme";
            // 
            // lblstrtkm
            // 
            this.lblstrtkm.AutoSize = true;
            this.lblstrtkm.BackColor = System.Drawing.Color.Transparent;
            this.lblstrtkm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblstrtkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstrtkm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblstrtkm.Location = new System.Drawing.Point(39, 541);
            this.lblstrtkm.Name = "lblstrtkm";
            this.lblstrtkm.Size = new System.Drawing.Size(170, 24);
            this.lblstrtkm.TabIndex = 43;
            this.lblstrtkm.Text = "Start_Km_Reading";
            // 
            // lblendkm
            // 
            this.lblendkm.AutoSize = true;
            this.lblendkm.BackColor = System.Drawing.Color.Transparent;
            this.lblendkm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblendkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblendkm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblendkm.Location = new System.Drawing.Point(39, 593);
            this.lblendkm.Name = "lblendkm";
            this.lblendkm.Size = new System.Drawing.Size(162, 24);
            this.lblendkm.TabIndex = 44;
            this.lblendkm.Text = "End_Km_Reading";
            // 
            // lbltourchrge
            // 
            this.lbltourchrge.AutoSize = true;
            this.lbltourchrge.BackColor = System.Drawing.Color.Transparent;
            this.lbltourchrge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbltourchrge.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltourchrge.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lbltourchrge.Location = new System.Drawing.Point(24, 39);
            this.lbltourchrge.Name = "lbltourchrge";
            this.lbltourchrge.Size = new System.Drawing.Size(123, 25);
            this.lbltourchrge.TabIndex = 48;
            this.lbltourchrge.Text = "Tour_Charge";
            // 
            // lblextrakmchrge
            // 
            this.lblextrakmchrge.AutoSize = true;
            this.lblextrakmchrge.BackColor = System.Drawing.Color.Transparent;
            this.lblextrakmchrge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblextrakmchrge.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblextrakmchrge.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lblextrakmchrge.Location = new System.Drawing.Point(24, 99);
            this.lblextrakmchrge.Name = "lblextrakmchrge";
            this.lblextrakmchrge.Size = new System.Drawing.Size(171, 25);
            this.lblextrakmchrge.TabIndex = 49;
            this.lblextrakmchrge.Text = "Extra_Km_Charge";
            // 
            // lblwaitngchrge
            // 
            this.lblwaitngchrge.AutoSize = true;
            this.lblwaitngchrge.BackColor = System.Drawing.Color.Transparent;
            this.lblwaitngchrge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblwaitngchrge.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwaitngchrge.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lblwaitngchrge.Location = new System.Drawing.Point(24, 156);
            this.lblwaitngchrge.Name = "lblwaitngchrge";
            this.lblwaitngchrge.Size = new System.Drawing.Size(144, 25);
            this.lblwaitngchrge.TabIndex = 50;
            this.lblwaitngchrge.Text = "Waiting_charge";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.BackColor = System.Drawing.Color.Transparent;
            this.lbltotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbltotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lbltotal.Location = new System.Drawing.Point(24, 214);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(55, 25);
            this.lbltotal.TabIndex = 51;
            this.lbltotal.Text = "Total";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.btncalculate);
            this.panel1.Controls.Add(this.txttotal);
            this.panel1.Controls.Add(this.txtextrkmfullchrge);
            this.panel1.Controls.Add(this.txtwaitingfullchrge);
            this.panel1.Controls.Add(this.txttourchrge);
            this.panel1.Controls.Add(this.lblwaitngchrge);
            this.panel1.Controls.Add(this.lbltourchrge);
            this.panel1.Controls.Add(this.lbltotal);
            this.panel1.Controls.Add(this.lblextrakmchrge);
            this.panel1.Location = new System.Drawing.Point(767, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(445, 345);
            this.panel1.TabIndex = 56;
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.DarkRed;
            this.btncalculate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.ForeColor = System.Drawing.SystemColors.Control;
            this.btncalculate.Location = new System.Drawing.Point(172, 287);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(144, 40);
            this.btncalculate.TabIndex = 1;
            this.btncalculate.Text = "Calculate";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // txttotal
            // 
            this.txttotal.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotal.Location = new System.Drawing.Point(256, 211);
            this.txttotal.Multiline = true;
            this.txttotal.Name = "txttotal";
            this.txttotal.ReadOnly = true;
            this.txttotal.Size = new System.Drawing.Size(180, 37);
            this.txttotal.TabIndex = 61;
            this.txttotal.Text = "0.00";
            // 
            // txtextrkmfullchrge
            // 
            this.txtextrkmfullchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtextrkmfullchrge.Location = new System.Drawing.Point(256, 96);
            this.txtextrkmfullchrge.Multiline = true;
            this.txtextrkmfullchrge.Name = "txtextrkmfullchrge";
            this.txtextrkmfullchrge.ReadOnly = true;
            this.txtextrkmfullchrge.Size = new System.Drawing.Size(180, 37);
            this.txtextrkmfullchrge.TabIndex = 60;
            this.txtextrkmfullchrge.Text = "0.00";
            // 
            // txtwaitingfullchrge
            // 
            this.txtwaitingfullchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwaitingfullchrge.Location = new System.Drawing.Point(256, 153);
            this.txtwaitingfullchrge.Multiline = true;
            this.txtwaitingfullchrge.Name = "txtwaitingfullchrge";
            this.txtwaitingfullchrge.ReadOnly = true;
            this.txtwaitingfullchrge.Size = new System.Drawing.Size(180, 37);
            this.txtwaitingfullchrge.TabIndex = 59;
            this.txtwaitingfullchrge.Text = "0.00";
            // 
            // txttourchrge
            // 
            this.txttourchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttourchrge.Location = new System.Drawing.Point(256, 36);
            this.txttourchrge.Multiline = true;
            this.txttourchrge.Name = "txttourchrge";
            this.txttourchrge.ReadOnly = true;
            this.txttourchrge.Size = new System.Drawing.Size(180, 37);
            this.txttourchrge.TabIndex = 58;
            this.txttourchrge.Tag = "0.00";
            this.txttourchrge.Text = "0.00";
            // 
            // txtbxdayrentid
            // 
            this.txtbxdayrentid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxdayrentid.Location = new System.Drawing.Point(278, 80);
            this.txtbxdayrentid.Multiline = true;
            this.txtbxdayrentid.Name = "txtbxdayrentid";
            this.txtbxdayrentid.Size = new System.Drawing.Size(180, 37);
            this.txtbxdayrentid.TabIndex = 57;
            this.txtbxdayrentid.TextChanged += new System.EventHandler(this.txtbxrentid_TextChanged);
            // 
            // txtstrtrdng
            // 
            this.txtstrtrdng.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstrtrdng.Location = new System.Drawing.Point(279, 538);
            this.txtstrtrdng.Multiline = true;
            this.txtstrtrdng.Name = "txtstrtrdng";
            this.txtstrtrdng.Size = new System.Drawing.Size(189, 37);
            this.txtstrtrdng.TabIndex = 58;
            // 
            // txtendrdng
            // 
            this.txtendrdng.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtendrdng.Location = new System.Drawing.Point(279, 590);
            this.txtendrdng.Multiline = true;
            this.txtendrdng.Name = "txtendrdng";
            this.txtendrdng.Size = new System.Drawing.Size(189, 37);
            this.txtendrdng.TabIndex = 59;
            // 
            // cmbvehcl
            // 
            this.cmbvehcl.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbvehcl.FormattingEnabled = true;
            this.cmbvehcl.Location = new System.Drawing.Point(276, 331);
            this.cmbvehcl.Name = "cmbvehcl";
            this.cmbvehcl.Size = new System.Drawing.Size(189, 28);
            this.cmbvehcl.TabIndex = 65;
            this.cmbvehcl.SelectedIndexChanged += new System.EventHandler(this.cmbvehcl_SelectedIndexChanged);
            // 
            // cmbpack
            // 
            this.cmbpack.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbpack.FormattingEnabled = true;
            this.cmbpack.Items.AddRange(new object[] {
            "100 Km per Day",
            "200 Km per Day",
            "Airportdrop",
            "Airportpickup"});
            this.cmbpack.Location = new System.Drawing.Point(276, 377);
            this.cmbpack.Name = "cmbpack";
            this.cmbpack.Size = new System.Drawing.Size(189, 28);
            this.cmbpack.TabIndex = 66;
            // 
            // btnhme
            // 
            this.btnhme.BackColor = System.Drawing.Color.DarkRed;
            this.btnhme.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhme.ForeColor = System.Drawing.SystemColors.Control;
            this.btnhme.Location = new System.Drawing.Point(1090, 24);
            this.btnhme.Name = "btnhme";
            this.btnhme.Size = new System.Drawing.Size(111, 40);
            this.btnhme.TabIndex = 7;
            this.btnhme.Text = "Home";
            this.btnhme.UseVisualStyleBackColor = false;
            this.btnhme.Click += new System.EventHandler(this.btnhme_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.DarkRed;
            this.clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.ForeColor = System.Drawing.SystemColors.Control;
            this.clear.Location = new System.Drawing.Point(584, 737);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(112, 40);
            this.clear.TabIndex = 67;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtnumber
            // 
            this.txtnumber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumber.Location = new System.Drawing.Point(278, 193);
            this.txtnumber.Multiline = true;
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(180, 37);
            this.txtnumber.TabIndex = 71;
            // 
            // txtbxcustomer
            // 
            this.txtbxcustomer.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxcustomer.Location = new System.Drawing.Point(278, 135);
            this.txtbxcustomer.Multiline = true;
            this.txtbxcustomer.Name = "txtbxcustomer";
            this.txtbxcustomer.Size = new System.Drawing.Size(180, 40);
            this.txtbxcustomer.TabIndex = 70;
            // 
            // lblnmber
            // 
            this.lblnmber.AutoSize = true;
            this.lblnmber.BackColor = System.Drawing.Color.Transparent;
            this.lblnmber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblnmber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnmber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblnmber.Location = new System.Drawing.Point(38, 195);
            this.lblnmber.Name = "lblnmber";
            this.lblnmber.Size = new System.Drawing.Size(92, 24);
            this.lblnmber.TabIndex = 69;
            this.lblnmber.Text = "Phone No";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.BackColor = System.Drawing.Color.Transparent;
            this.lblcustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcustomer.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcustomer.Location = new System.Drawing.Point(40, 138);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(145, 24);
            this.lblcustomer.TabIndex = 68;
            this.lblcustomer.Text = "Customer Name";
            // 
            // dtpstart
            // 
            this.dtpstart.CalendarFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpstart.CustomFormat = "yyyy/MM/dd HH:mm";
            this.dtpstart.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpstart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpstart.Location = new System.Drawing.Point(276, 435);
            this.dtpstart.Name = "dtpstart";
            this.dtpstart.Size = new System.Drawing.Size(189, 28);
            this.dtpstart.TabIndex = 73;
            // 
            // dtpend
            // 
            this.dtpend.CalendarFont = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpend.CustomFormat = "yyyy/MM/dd HH:mm";
            this.dtpend.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpend.Location = new System.Drawing.Point(276, 481);
            this.dtpend.Name = "dtpend";
            this.dtpend.Size = new System.Drawing.Size(189, 28);
            this.dtpend.TabIndex = 74;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(702, 450);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(510, 268);
            this.dataGridView1.TabIndex = 76;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(702, 450);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(510, 268);
            this.pictureBox1.TabIndex = 75;
            this.pictureBox1.TabStop = false;
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkRed;
            this.btnview.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.SystemColors.Control;
            this.btnview.Location = new System.Drawing.Point(713, 736);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(112, 40);
            this.btnview.TabIndex = 77;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1240, 798);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dtpend);
            this.Controls.Add(this.dtpstart);
            this.Controls.Add(this.txtnumber);
            this.Controls.Add(this.txtbxcustomer);
            this.Controls.Add(this.lblnmber);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.btnhme);
            this.Controls.Add(this.cmbpack);
            this.Controls.Add(this.cmbvehcl);
            this.Controls.Add(this.txtendrdng);
            this.Controls.Add(this.txtstrtrdng);
            this.Controls.Add(this.txtbxdayrentid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblendkm);
            this.Controls.Add(this.lblstrtkm);
            this.Controls.Add(this.lblendtym);
            this.Controls.Add(this.lblstrttym);
            this.Controls.Add(this.lblpckge);
            this.Controls.Add(this.lblvehicle);
            this.Controls.Add(this.lbldayid);
            this.Controls.Add(this.srchbtn);
            this.Controls.Add(this.dltbtn);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.savebtn);
            this.Controls.Add(this.extbtn);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Day Tour";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button extbtn;
        private System.Windows.Forms.Button srchbtn;
        private System.Windows.Forms.Button dltbtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button savebtn;
        private System.Windows.Forms.Label lbldayid;
        private System.Windows.Forms.Label lblvehicle;
        private System.Windows.Forms.Label lblpckge;
        private System.Windows.Forms.Label lblstrttym;
        private System.Windows.Forms.Label lblendtym;
        private System.Windows.Forms.Label lblstrtkm;
        private System.Windows.Forms.Label lblendkm;
        private System.Windows.Forms.Label lbltourchrge;
        private System.Windows.Forms.Label lblextrakmchrge;
        private System.Windows.Forms.Label lblwaitngchrge;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtbxdayrentid;
        private System.Windows.Forms.TextBox txtstrtrdng;
        private System.Windows.Forms.TextBox txtendrdng;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtextrkmfullchrge;
        private System.Windows.Forms.TextBox txtwaitingfullchrge;
        private System.Windows.Forms.TextBox txttourchrge;
        private System.Windows.Forms.ComboBox cmbvehcl;
        private System.Windows.Forms.ComboBox cmbpack;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Button btnhme;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.TextBox txtnumber;
        private System.Windows.Forms.TextBox txtbxcustomer;
        private System.Windows.Forms.Label lblnmber;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.DateTimePicker dtpstart;
        private System.Windows.Forms.DateTimePicker dtpend;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Timer timer1;
    }
}