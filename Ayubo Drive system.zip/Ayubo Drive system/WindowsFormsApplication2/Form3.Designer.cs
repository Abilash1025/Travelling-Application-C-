﻿namespace WindowsFormsApplication2
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.daybtn = new System.Windows.Forms.Button();
            this.longbtn = new System.Windows.Forms.Button();
            this.extbtn = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnrent = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(441, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(419, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to Ayubo Drive";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(412, 140);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(816, 486);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // daybtn
            // 
            this.daybtn.BackColor = System.Drawing.Color.DarkRed;
            this.daybtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daybtn.ForeColor = System.Drawing.SystemColors.Control;
            this.daybtn.Location = new System.Drawing.Point(79, 352);
            this.daybtn.Name = "daybtn";
            this.daybtn.Size = new System.Drawing.Size(153, 44);
            this.daybtn.TabIndex = 3;
            this.daybtn.Text = "Day Tour";
            this.daybtn.UseVisualStyleBackColor = false;
            this.daybtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // longbtn
            // 
            this.longbtn.BackColor = System.Drawing.Color.DarkRed;
            this.longbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.longbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.longbtn.Location = new System.Drawing.Point(79, 449);
            this.longbtn.Name = "longbtn";
            this.longbtn.Size = new System.Drawing.Size(153, 44);
            this.longbtn.TabIndex = 4;
            this.longbtn.Text = "Long Tour";
            this.longbtn.UseVisualStyleBackColor = false;
            this.longbtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // extbtn
            // 
            this.extbtn.BackColor = System.Drawing.Color.DarkRed;
            this.extbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.extbtn.Location = new System.Drawing.Point(1089, 747);
            this.extbtn.Name = "extbtn";
            this.extbtn.Size = new System.Drawing.Size(99, 39);
            this.extbtn.TabIndex = 5;
            this.extbtn.Text = "Exit";
            this.extbtn.UseVisualStyleBackColor = false;
            this.extbtn.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.DarkRed;
            this.btnadd.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.SystemColors.Control;
            this.btnadd.Location = new System.Drawing.Point(79, 168);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(153, 44);
            this.btnadd.TabIndex = 1;
            this.btnadd.Text = "Add Vehicle";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnrent
            // 
            this.btnrent.BackColor = System.Drawing.Color.DarkRed;
            this.btnrent.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrent.ForeColor = System.Drawing.SystemColors.Control;
            this.btnrent.Location = new System.Drawing.Point(79, 255);
            this.btnrent.Name = "btnrent";
            this.btnrent.Size = new System.Drawing.Size(153, 46);
            this.btnrent.TabIndex = 2;
            this.btnrent.Text = "Rent";
            this.btnrent.UseVisualStyleBackColor = false;
            this.btnrent.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1240, 798);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnrent);
            this.Controls.Add(this.extbtn);
            this.Controls.Add(this.longbtn);
            this.Controls.Add(this.daybtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form7";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ayubo Drive system";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button daybtn;
        private System.Windows.Forms.Button longbtn;
        private System.Windows.Forms.Button extbtn;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnrent;
    }
}