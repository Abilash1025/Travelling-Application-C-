﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            FillComboBox();
        }

        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=Ayubo;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        private double driverCharge;
        int rentid, vehicleid;
        string customername, phonenumber, vehiclepayment, driverpayment, total;
        DateTime strtdate, enddate;
        SqlDataAdapter chart;
        DataTable dt;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form7 f = new Form7();
            f.Show();
            this.Hide();
        }

        private void rad_rent_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btncalculate_Click(object sender, EventArgs e)
        {

            DateTime startdate = dtprented.Value;
            DateTime enddate = dtpreturn.Value;
            string vehicleid = cmdvehicle.SelectedValue.ToString();
            double basiccharge = 0.0;

            if (rad_rent.Checked)
            {
                basiccharge = rentcalculation(vehicleid, startdate, enddate, false);
            }
            else if (rad_rentdriver.Checked)
            {
                basiccharge = rentcalculation(vehicleid, startdate, enddate, true);
            }
            txtbxvhclpay.Text = string.Format("{0:.00}", basiccharge);

        }
        public double rentcalculation(string vehicleid, DateTime startdate, DateTime enddate, bool witthdriver)
        {
            double rent = 0.0;
            try
            {
                SqlCommand cmd = new SqlCommand("select* from Table_ADD1", con);
                cmd.Parameters.AddWithValue("@001", vehicleid);
                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    double daycharge = double.Parse(r["Day_rent"].ToString());
                    double weekcharge = double.Parse(r["Week_rent"].ToString());
                    double monthlycharge = double.Parse(r["Month_rent"].ToString());
                    driverCharge = double.Parse(r["Driver_charge"].ToString());
                    TimeSpan ts = enddate.Date - startdate.Date;
                    int total_days = ts.Days + 1;
                    int days = total_days;
                    int month = (int)days / 30;
                    days = days % 30;
                    int weekcount = (int)days / 7;
                    days = days % 7;

                    rent = month * monthlycharge + weekcount * weekcharge + days * daycharge;

                    if (witthdriver)
                    {
                        driverCharge = total_days * driverCharge;
                        txtbxdrvrtotal.Text = driverCharge.ToString();

                        double totalcharge = rent + driverCharge;
                        txtbxtotal.Text = totalcharge.ToString();

                    }
                    else
                    {
                        txtbxdrvrtotal.Text = "0.0";
                        txtbxtotal.Text = rent.ToString();
                    }
                }
            }
            catch (SqlException e)
            {
                e.ToString();
            }
            finally
            {
                con.Close();
            }
            return rent;
        }

        private void FillComboBox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select V_Name from Table_ADD1", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmdvehicle.DataSource = dt;
            cmdvehicle.DisplayMember = "V_Name";
            cmdvehicle.ValueMember = "V_Name";


        }

        private void srchbtn_Click(object sender, EventArgs e)
        {
            if (txtbxrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                rentid = int.Parse(txtbxrentid.Text);
                string search = "Select *from Table_Rent where Rent_id='" + rentid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    txtcustomer.Text = r["Cutomer_name"].ToString();
                    txtbnumber.Text = r["Phone_no"].ToString();
                    cmdvehicle.Text = r["Rent_vehicleid"].ToString();
                    dtprented.Text = r["Rented_Date"].ToString();
                    dtpreturn.Text = r["Returned_date"].ToString();
                    txtbxvhclpay.Text = r["Vehicle_payment"].ToString();
                    txtbxdrvrtotal.Text = r["Driver_payment"].ToString();
                    txtbxtotal.Text = r["Total"].ToString();
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        private void savebtn_Click(object sender, EventArgs e)
        {
            if (txtbxrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                rentid = int.Parse(txtbxrentid.Text);
                customername = txtcustomer.Text;
                phonenumber = txtbnumber.Text;
                vehicleid = int.Parse(cmdvehicle.Text);
                strtdate = dtprented.Value.Date;
                enddate = dtpreturn.Value.Date;
                vehiclepayment = txtbxvhclpay.Text;
                driverpayment = txtbxdrvrtotal.Text;
                total = txtbxtotal.Text;

                con.Open();

                string insert = "insert into Table_Rent values ('" + rentid + "','" + customername + "','" + phonenumber + "','" + vehicleid + "','" +
                    strtdate + "','" + enddate + "','" + vehiclepayment + "','" + driverpayment + "','" + total + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Successfully Save", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (txtbxrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {

                rentid = int.Parse(txtbxrentid.Text);
                customername = txtcustomer.Text;
                phonenumber = txtbnumber.Text;
                vehicleid = int.Parse(cmdvehicle.Text);
                strtdate = dtprented.Value.Date;
                enddate = dtpreturn.Value.Date;
                vehiclepayment = txtbxvhclpay.Text;
                driverpayment = txtbxdrvrtotal.Text;
                total = txtbxtotal.Text;

                string update = "update Table_Rent set Cutomer_name = '" + customername + "',Phone_no = '" + phonenumber + "',Rent_vehicleid = '" +
                    vehicleid + "',Rented_Date = '" + strtdate + "',Returned_date = '" + enddate + "',Vehicle_payment = '" +
                    vehiclepayment + "',Driver_payment = '" + driverpayment + "',Total = '" + total + "' where Rent_id = '" + rentid + "'";
                if (MessageBox.Show("Are you going to update?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated");
                    con.Close();

                }
            }
        }
        private void dltbtn_Click(object sender, EventArgs e)
        {
            if (txtbxrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                string delete = "Delete from Table_Rent where Rent_id='" + rentid + "' ";
                SqlCommand cmd = new SqlCommand(delete, con);

                if (MessageBox.Show("Are you want to delete a exisisting record?", "confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Deleted Sucessfuly", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtbxrentid.Clear();
            txtcustomer.Clear();
            txtbnumber.Clear();
            rad_rent.Checked = false;
            rad_rentdriver.Checked = false;
            cmdvehicle.ResetText();
            dtprented.ResetText();
            dtpreturn.ResetText();
            txtbxvhclpay.Clear();
            txtbxdrvrtotal.Clear();
            txtbxtotal.Clear();


        }

        private void Form5_Load_1(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnview_Click_1(object sender, EventArgs e)
        {
            chart = new SqlDataAdapter("Select * from Table_Rent ", con);
            dt = new DataTable();
            chart.Fill(dt);
            dataGridView1.DataSource = dt;

            pictureBox1.Visible = false;
            dataGridView1.Visible = true;


        }
    }
}
