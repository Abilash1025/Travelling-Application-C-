﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            progressBar1.Visible = false;
        }
        string Username;
        string Password;

        private void button1_Click(object sender, EventArgs e)
        {
            Username = textBox2.Text;
            Password = textBox3.Text;

            if (Username == "Ayubo" && Password == "Drive123")
            {
                progressBar1.Visible = true;
                timer1.Start();
            }
            else
            {
                MessageBox.Show("Invalid username & password", "Configuration", MessageBoxButtons.OK, MessageBoxIcon.Error);

                textBox2.Clear();
                textBox3.Clear();

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value = progressBar1.Value + 5;
            }
            else
            {
                timer1.Enabled = false;
                Form7 f7 = new Form7();
                f7.Show();
                this.Hide();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                textBox3.PasswordChar = '\0';
            }
            if (checkBox1.Checked == false)
            {
                textBox3.PasswordChar = '*';
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
