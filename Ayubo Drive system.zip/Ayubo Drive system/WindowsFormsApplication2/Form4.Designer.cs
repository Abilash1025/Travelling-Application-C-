﻿namespace WindowsFormsApplication2
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.label1 = new System.Windows.Forms.Label();
            this.Hmebtn = new System.Windows.Forms.Button();
            this.extbtn = new System.Windows.Forms.Button();
            this.idlabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.typelabel = new System.Windows.Forms.Label();
            this.colorlabel = new System.Windows.Forms.Label();
            this.peoplelabel = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txttype = new System.Windows.Forms.TextBox();
            this.txtcolor = new System.Windows.Forms.TextBox();
            this.txtpassesngers = new System.Windows.Forms.TextBox();
            this.updatebtn = new System.Windows.Forms.Button();
            this.dltbtn = new System.Windows.Forms.Button();
            this.srchbtn = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.txtwaiting = new System.Windows.Forms.TextBox();
            this.txtdriver = new System.Windows.Forms.TextBox();
            this.txtextrakm = new System.Windows.Forms.TextBox();
            this.lblextra1km = new System.Windows.Forms.Label();
            this.lbldriver = new System.Windows.Forms.Label();
            this.lblwaiting = new System.Windows.Forms.Label();
            this.txtweekrent = new System.Windows.Forms.TextBox();
            this.txtmonthrent = new System.Windows.Forms.TextBox();
            this.txt400 = new System.Windows.Forms.TextBox();
            this.txt300 = new System.Windows.Forms.TextBox();
            this.txt100 = new System.Windows.Forms.TextBox();
            this.txt200 = new System.Windows.Forms.TextBox();
            this.txtdayrent = new System.Windows.Forms.TextBox();
            this.lblday = new System.Windows.Forms.Label();
            this.lblweek = new System.Windows.Forms.Label();
            this.lblmonth = new System.Windows.Forms.Label();
            this.lbl100 = new System.Windows.Forms.Label();
            this.lbl200 = new System.Windows.Forms.Label();
            this.lbl300 = new System.Windows.Forms.Label();
            this.lbl400 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt1km = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Btnclear = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnview = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(502, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Vehicle";
            // 
            // Hmebtn
            // 
            this.Hmebtn.BackColor = System.Drawing.Color.DarkRed;
            this.Hmebtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hmebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.Hmebtn.Location = new System.Drawing.Point(1097, 31);
            this.Hmebtn.Name = "Hmebtn";
            this.Hmebtn.Size = new System.Drawing.Size(111, 40);
            this.Hmebtn.TabIndex = 5;
            this.Hmebtn.Text = "Home";
            this.Hmebtn.UseVisualStyleBackColor = false;
            this.Hmebtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // extbtn
            // 
            this.extbtn.BackColor = System.Drawing.Color.DarkRed;
            this.extbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.extbtn.Location = new System.Drawing.Point(1097, 746);
            this.extbtn.Name = "extbtn";
            this.extbtn.Size = new System.Drawing.Size(111, 40);
            this.extbtn.TabIndex = 6;
            this.extbtn.Text = "Exit";
            this.extbtn.UseVisualStyleBackColor = false;
            this.extbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // idlabel
            // 
            this.idlabel.AutoSize = true;
            this.idlabel.BackColor = System.Drawing.Color.Transparent;
            this.idlabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.idlabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idlabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.idlabel.Location = new System.Drawing.Point(72, 131);
            this.idlabel.Name = "idlabel";
            this.idlabel.Size = new System.Drawing.Size(99, 25);
            this.idlabel.TabIndex = 3;
            this.idlabel.Text = "Vehicle ID";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.BackColor = System.Drawing.Color.Transparent;
            this.namelabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.namelabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.namelabel.Location = new System.Drawing.Point(72, 199);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(61, 25);
            this.namelabel.TabIndex = 4;
            this.namelabel.Text = "Name";
            // 
            // typelabel
            // 
            this.typelabel.AutoSize = true;
            this.typelabel.BackColor = System.Drawing.Color.Transparent;
            this.typelabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.typelabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typelabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.typelabel.Location = new System.Drawing.Point(72, 261);
            this.typelabel.Name = "typelabel";
            this.typelabel.Size = new System.Drawing.Size(54, 25);
            this.typelabel.TabIndex = 5;
            this.typelabel.Text = "Type";
            // 
            // colorlabel
            // 
            this.colorlabel.AutoSize = true;
            this.colorlabel.BackColor = System.Drawing.Color.Transparent;
            this.colorlabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.colorlabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorlabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.colorlabel.Location = new System.Drawing.Point(72, 326);
            this.colorlabel.Name = "colorlabel";
            this.colorlabel.Size = new System.Drawing.Size(59, 25);
            this.colorlabel.TabIndex = 6;
            this.colorlabel.Text = "Color";
            // 
            // peoplelabel
            // 
            this.peoplelabel.AutoSize = true;
            this.peoplelabel.BackColor = System.Drawing.Color.Transparent;
            this.peoplelabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.peoplelabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.peoplelabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.peoplelabel.Location = new System.Drawing.Point(72, 388);
            this.peoplelabel.Name = "peoplelabel";
            this.peoplelabel.Size = new System.Drawing.Size(104, 25);
            this.peoplelabel.TabIndex = 7;
            this.peoplelabel.Text = "passengers";
            // 
            // txtid
            // 
            this.txtid.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(300, 131);
            this.txtid.Multiline = true;
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(144, 31);
            this.txtid.TabIndex = 9;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(300, 199);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(144, 31);
            this.txtname.TabIndex = 10;
            // 
            // txttype
            // 
            this.txttype.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttype.Location = new System.Drawing.Point(300, 261);
            this.txttype.Multiline = true;
            this.txttype.Name = "txttype";
            this.txttype.Size = new System.Drawing.Size(144, 31);
            this.txttype.TabIndex = 11;
            // 
            // txtcolor
            // 
            this.txtcolor.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcolor.Location = new System.Drawing.Point(300, 326);
            this.txtcolor.Multiline = true;
            this.txtcolor.Name = "txtcolor";
            this.txtcolor.Size = new System.Drawing.Size(144, 31);
            this.txtcolor.TabIndex = 12;
            // 
            // txtpassesngers
            // 
            this.txtpassesngers.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassesngers.Location = new System.Drawing.Point(300, 388);
            this.txtpassesngers.Multiline = true;
            this.txtpassesngers.Name = "txtpassesngers";
            this.txtpassesngers.Size = new System.Drawing.Size(144, 31);
            this.txtpassesngers.TabIndex = 13;
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.DarkRed;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.updatebtn.Location = new System.Drawing.Point(194, 746);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(112, 40);
            this.updatebtn.TabIndex = 1;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = false;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // dltbtn
            // 
            this.dltbtn.BackColor = System.Drawing.Color.DarkRed;
            this.dltbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dltbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.dltbtn.Location = new System.Drawing.Point(348, 746);
            this.dltbtn.Name = "dltbtn";
            this.dltbtn.Size = new System.Drawing.Size(112, 40);
            this.dltbtn.TabIndex = 2;
            this.dltbtn.Text = "Delete";
            this.dltbtn.UseVisualStyleBackColor = false;
            this.dltbtn.Click += new System.EventHandler(this.dltbtn_Click);
            // 
            // srchbtn
            // 
            this.srchbtn.BackColor = System.Drawing.Color.DarkRed;
            this.srchbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.srchbtn.Location = new System.Drawing.Point(493, 746);
            this.srchbtn.Name = "srchbtn";
            this.srchbtn.Size = new System.Drawing.Size(112, 40);
            this.srchbtn.TabIndex = 3;
            this.srchbtn.Text = "Search";
            this.srchbtn.UseVisualStyleBackColor = false;
            this.srchbtn.Click += new System.EventHandler(this.srchbtn_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.DarkRed;
            this.Add.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.SystemColors.Control;
            this.Add.Location = new System.Drawing.Point(59, 746);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(112, 40);
            this.Add.TabIndex = 4;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // txtwaiting
            // 
            this.txtwaiting.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwaiting.Location = new System.Drawing.Point(1005, 641);
            this.txtwaiting.Multiline = true;
            this.txtwaiting.Name = "txtwaiting";
            this.txtwaiting.Size = new System.Drawing.Size(144, 27);
            this.txtwaiting.TabIndex = 30;
            // 
            // txtdriver
            // 
            this.txtdriver.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdriver.Location = new System.Drawing.Point(1005, 599);
            this.txtdriver.Multiline = true;
            this.txtdriver.Name = "txtdriver";
            this.txtdriver.Size = new System.Drawing.Size(144, 27);
            this.txtdriver.TabIndex = 29;
            // 
            // txtextrakm
            // 
            this.txtextrakm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtextrakm.Location = new System.Drawing.Point(1005, 553);
            this.txtextrakm.Multiline = true;
            this.txtextrakm.Name = "txtextrakm";
            this.txtextrakm.Size = new System.Drawing.Size(144, 27);
            this.txtextrakm.TabIndex = 28;
            // 
            // lblextra1km
            // 
            this.lblextra1km.AutoSize = true;
            this.lblextra1km.BackColor = System.Drawing.Color.Transparent;
            this.lblextra1km.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblextra1km.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblextra1km.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblextra1km.Location = new System.Drawing.Point(835, 559);
            this.lblextra1km.Name = "lblextra1km";
            this.lblextra1km.Size = new System.Drawing.Size(109, 25);
            this.lblextra1km.TabIndex = 27;
            this.lblextra1km.Text = "Extra 1 Km";
            // 
            // lbldriver
            // 
            this.lbldriver.AutoSize = true;
            this.lbldriver.BackColor = System.Drawing.Color.Transparent;
            this.lbldriver.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbldriver.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldriver.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbldriver.Location = new System.Drawing.Point(835, 602);
            this.lbldriver.Name = "lbldriver";
            this.lbldriver.Size = new System.Drawing.Size(67, 25);
            this.lbldriver.TabIndex = 26;
            this.lbldriver.Text = "Driver";
            // 
            // lblwaiting
            // 
            this.lblwaiting.AutoSize = true;
            this.lblwaiting.BackColor = System.Drawing.Color.Transparent;
            this.lblwaiting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblwaiting.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwaiting.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblwaiting.Location = new System.Drawing.Point(835, 644);
            this.lblwaiting.Name = "lblwaiting";
            this.lblwaiting.Size = new System.Drawing.Size(77, 25);
            this.lblwaiting.TabIndex = 25;
            this.lblwaiting.Text = "Waiting";
            // 
            // txtweekrent
            // 
            this.txtweekrent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtweekrent.Location = new System.Drawing.Point(1005, 183);
            this.txtweekrent.Multiline = true;
            this.txtweekrent.Name = "txtweekrent";
            this.txtweekrent.Size = new System.Drawing.Size(144, 27);
            this.txtweekrent.TabIndex = 48;
            // 
            // txtmonthrent
            // 
            this.txtmonthrent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonthrent.Location = new System.Drawing.Point(1005, 228);
            this.txtmonthrent.Multiline = true;
            this.txtmonthrent.Name = "txtmonthrent";
            this.txtmonthrent.Size = new System.Drawing.Size(144, 27);
            this.txtmonthrent.TabIndex = 47;
            // 
            // txt400
            // 
            this.txt400.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt400.Location = new System.Drawing.Point(1005, 402);
            this.txt400.Multiline = true;
            this.txt400.Name = "txt400";
            this.txt400.Size = new System.Drawing.Size(144, 27);
            this.txt400.TabIndex = 44;
            // 
            // txt300
            // 
            this.txt300.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt300.Location = new System.Drawing.Point(1005, 359);
            this.txt300.Multiline = true;
            this.txt300.Name = "txt300";
            this.txt300.Size = new System.Drawing.Size(144, 27);
            this.txt300.TabIndex = 43;
            // 
            // txt100
            // 
            this.txt100.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt100.Location = new System.Drawing.Point(1005, 274);
            this.txt100.Multiline = true;
            this.txt100.Name = "txt100";
            this.txt100.Size = new System.Drawing.Size(144, 27);
            this.txt100.TabIndex = 42;
            // 
            // txt200
            // 
            this.txt200.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt200.Location = new System.Drawing.Point(1005, 317);
            this.txt200.Multiline = true;
            this.txt200.Name = "txt200";
            this.txt200.Size = new System.Drawing.Size(144, 27);
            this.txt200.TabIndex = 41;
            // 
            // txtdayrent
            // 
            this.txtdayrent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdayrent.Location = new System.Drawing.Point(1005, 137);
            this.txtdayrent.Multiline = true;
            this.txtdayrent.Name = "txtdayrent";
            this.txtdayrent.Size = new System.Drawing.Size(144, 27);
            this.txtdayrent.TabIndex = 40;
            // 
            // lblday
            // 
            this.lblday.AutoSize = true;
            this.lblday.BackColor = System.Drawing.Color.Transparent;
            this.lblday.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblday.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblday.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblday.Location = new System.Drawing.Point(835, 140);
            this.lblday.Name = "lblday";
            this.lblday.Size = new System.Drawing.Size(92, 25);
            this.lblday.TabIndex = 39;
            this.lblday.Text = "Day Rent";
            // 
            // lblweek
            // 
            this.lblweek.AutoSize = true;
            this.lblweek.BackColor = System.Drawing.Color.Transparent;
            this.lblweek.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblweek.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblweek.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblweek.Location = new System.Drawing.Point(835, 186);
            this.lblweek.Name = "lblweek";
            this.lblweek.Size = new System.Drawing.Size(107, 25);
            this.lblweek.TabIndex = 38;
            this.lblweek.Text = "Week Rent";
            // 
            // lblmonth
            // 
            this.lblmonth.AutoSize = true;
            this.lblmonth.BackColor = System.Drawing.Color.Transparent;
            this.lblmonth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblmonth.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonth.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblmonth.Location = new System.Drawing.Point(835, 231);
            this.lblmonth.Name = "lblmonth";
            this.lblmonth.Size = new System.Drawing.Size(113, 25);
            this.lblmonth.TabIndex = 37;
            this.lblmonth.Text = "Month Rent";
            // 
            // lbl100
            // 
            this.lbl100.AutoSize = true;
            this.lbl100.BackColor = System.Drawing.Color.Transparent;
            this.lbl100.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl100.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl100.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbl100.Location = new System.Drawing.Point(835, 277);
            this.lbl100.Name = "lbl100";
            this.lbl100.Size = new System.Drawing.Size(76, 25);
            this.lbl100.TabIndex = 34;
            this.lbl100.Text = "100 Km";
            // 
            // lbl200
            // 
            this.lbl200.AutoSize = true;
            this.lbl200.BackColor = System.Drawing.Color.Transparent;
            this.lbl200.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl200.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl200.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbl200.Location = new System.Drawing.Point(835, 320);
            this.lbl200.Name = "lbl200";
            this.lbl200.Size = new System.Drawing.Size(76, 25);
            this.lbl200.TabIndex = 33;
            this.lbl200.Text = "200 Km";
            // 
            // lbl300
            // 
            this.lbl300.AutoSize = true;
            this.lbl300.BackColor = System.Drawing.Color.Transparent;
            this.lbl300.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl300.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl300.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbl300.Location = new System.Drawing.Point(835, 362);
            this.lbl300.Name = "lbl300";
            this.lbl300.Size = new System.Drawing.Size(76, 25);
            this.lbl300.TabIndex = 32;
            this.lbl300.Text = "300 Km";
            // 
            // lbl400
            // 
            this.lbl400.AutoSize = true;
            this.lbl400.BackColor = System.Drawing.Color.Transparent;
            this.lbl400.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl400.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl400.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbl400.Location = new System.Drawing.Point(835, 405);
            this.lbl400.Name = "lbl400";
            this.lbl400.Size = new System.Drawing.Size(76, 25);
            this.lbl400.TabIndex = 31;
            this.lbl400.Text = "400 Km";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(835, 509);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 25);
            this.label2.TabIndex = 49;
            this.label2.Text = "For 1 Km";
            // 
            // txt1km
            // 
            this.txt1km.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1km.Location = new System.Drawing.Point(1005, 509);
            this.txt1km.Multiline = true;
            this.txt1km.Name = "txt1km";
            this.txt1km.Size = new System.Drawing.Size(144, 27);
            this.txt1km.TabIndex = 50;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 450);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(510, 290);
            this.pictureBox1.TabIndex = 51;
            this.pictureBox1.TabStop = false;
            // 
            // Btnclear
            // 
            this.Btnclear.BackColor = System.Drawing.Color.DarkRed;
            this.Btnclear.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnclear.ForeColor = System.Drawing.SystemColors.Control;
            this.Btnclear.Location = new System.Drawing.Point(640, 746);
            this.Btnclear.Name = "Btnclear";
            this.Btnclear.Size = new System.Drawing.Size(112, 40);
            this.Btnclear.TabIndex = 52;
            this.Btnclear.Text = "Clear";
            this.Btnclear.UseVisualStyleBackColor = false;
            this.Btnclear.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 450);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(510, 290);
            this.dataGridView1.TabIndex = 53;
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkRed;
            this.btnview.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.SystemColors.Control;
            this.btnview.Location = new System.Drawing.Point(774, 746);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(112, 40);
            this.btnview.TabIndex = 54;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1240, 798);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Btnclear);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt1km);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtweekrent);
            this.Controls.Add(this.txtmonthrent);
            this.Controls.Add(this.txt400);
            this.Controls.Add(this.txt300);
            this.Controls.Add(this.txt100);
            this.Controls.Add(this.txt200);
            this.Controls.Add(this.txtdayrent);
            this.Controls.Add(this.lblday);
            this.Controls.Add(this.lblweek);
            this.Controls.Add(this.lblmonth);
            this.Controls.Add(this.lbl100);
            this.Controls.Add(this.lbl200);
            this.Controls.Add(this.lbl300);
            this.Controls.Add(this.lbl400);
            this.Controls.Add(this.txtwaiting);
            this.Controls.Add(this.txtdriver);
            this.Controls.Add(this.txtextrakm);
            this.Controls.Add(this.lblextra1km);
            this.Controls.Add(this.lbldriver);
            this.Controls.Add(this.lblwaiting);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.srchbtn);
            this.Controls.Add(this.dltbtn);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.txtpassesngers);
            this.Controls.Add(this.txtcolor);
            this.Controls.Add(this.txttype);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.peoplelabel);
            this.Controls.Add(this.colorlabel);
            this.Controls.Add(this.typelabel);
            this.Controls.Add(this.namelabel);
            this.Controls.Add(this.idlabel);
            this.Controls.Add(this.extbtn);
            this.Controls.Add(this.Hmebtn);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Vehicle";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Hmebtn;
        private System.Windows.Forms.Button extbtn;
        private System.Windows.Forms.Label idlabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label typelabel;
        private System.Windows.Forms.Label colorlabel;
        private System.Windows.Forms.Label peoplelabel;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txttype;
        private System.Windows.Forms.TextBox txtcolor;
        private System.Windows.Forms.TextBox txtpassesngers;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button dltbtn;
        private System.Windows.Forms.Button srchbtn;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.TextBox txtwaiting;
        private System.Windows.Forms.TextBox txtdriver;
        private System.Windows.Forms.TextBox txtextrakm;
        private System.Windows.Forms.Label lblextra1km;
        private System.Windows.Forms.Label lbldriver;
        private System.Windows.Forms.Label lblwaiting;
        private System.Windows.Forms.TextBox txtweekrent;
        private System.Windows.Forms.TextBox txtmonthrent;
        private System.Windows.Forms.TextBox txt400;
        private System.Windows.Forms.TextBox txt300;
        private System.Windows.Forms.TextBox txt100;
        private System.Windows.Forms.TextBox txt200;
        private System.Windows.Forms.TextBox txtdayrent;
        private System.Windows.Forms.Label lblday;
        private System.Windows.Forms.Label lblweek;
        private System.Windows.Forms.Label lblmonth;
        private System.Windows.Forms.Label lbl100;
        private System.Windows.Forms.Label lbl200;
        private System.Windows.Forms.Label lbl300;
        private System.Windows.Forms.Label lbl400;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt1km;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Btnclear;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnview;
    }
}