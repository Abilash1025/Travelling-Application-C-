﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            FillComboBox();

        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=Ayubo;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        int tourcharge;
        int extra_km, waiting, Kms, Max_hr, Mak_km, daytourid, vhclid;
        string packages, customename, phonenumber, startkm, endkm, vehiclecharge, waitingcharge, extrakmchrge, total;
        DateTime strtdate, enddate;
        SqlDataAdapter chart;
        DataTable dt;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void txtbxrentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbvehcl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnhme_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            this.Hide();

        }

        private void btncalculate_Click(object sender, EventArgs e)
        {

            DateTime strt = dtpstart.Value;
            DateTime end = dtpend.Value;
            string package = cmbpack.SelectedItem.ToString();
            string vehicle = cmbvehcl.SelectedValue.ToString();
            string strtkm = txtstrtrdng.Text;
            string endkm = txtendrdng.Text;

            rentcalculation(strt, end, strtkm, endkm, package, vehicle);
        }

        private void FillComboBox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select V_Name from Table_ADD1", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbvehcl.DataSource = dt;
            cmbvehcl.DisplayMember = "V_Name";
            cmbvehcl.ValueMember = "V_Name";

        }

        private int rentcalculation(DateTime strt, DateTime end, string strtkm, string endkm, string package, string vehicle)
        {

            SqlCommand cmd = new SqlCommand("select* from Table_ADD1", con);
            cmd.Parameters.AddWithValue("@001", vehicle);

            con.Open();

            SqlDataReader r = cmd.ExecuteReader();

            if (r.Read())
            {
                int hundrekmpackrent = int.Parse(r["Hundredkm"].ToString());
                int twohundrekmpackrent = int.Parse(r["twohundredkm"].ToString());
                int extrakmchrge = int.Parse(r["Extrakm_charge"].ToString());
                int chrgeforwaiting = int.Parse(r["waiting_charge"].ToString());
                int kmcharge = int.Parse(r["Km_charge"].ToString());
                TimeSpan ts = end.Subtract(strt).Duration();
                double hour = ts.TotalHours;
                int totalhour = Convert.ToInt32(Math.Round(hour, 0, MidpointRounding.ToEven));
                Kms = int.Parse(txtendrdng.Text) - int.Parse(txtstrtrdng.Text);

                if (package == "100 Km per Day")
                {
                    Mak_km = 100;
                    Max_hr = 6;
                    int tour_charge1 = hundrekmpackrent;
                    txttourchrge.Text = tour_charge1.ToString();


                    if (Kms >= 100)
                    {
                        extra_km = (Kms - Mak_km) * extrakmchrge;

                        int extra_km1 = extra_km;
                        txtextrkmfullchrge.Text = extra_km1.ToString();

                        tourcharge = tour_charge1 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge1 = hundrekmpackrent;
                        txttourchrge.Text = tour_charge1.ToString();

                        tourcharge = tour_charge1 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    if (totalhour >= 6)
                    {
                        waiting = (totalhour - Max_hr) * chrgeforwaiting;

                        int waiting1 = waiting;
                        txtwaitingfullchrge.Text = waiting1.ToString();

                        tourcharge = tour_charge1 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge1 = hundrekmpackrent;
                        txttourchrge.Text = tour_charge1.ToString();

                        tourcharge = tour_charge1 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }


                }
                if (package == "200 Km per Day")
                {
                    Mak_km = 200;
                    Max_hr = 13;
                    int tour_charge2 = twohundrekmpackrent;
                    txttourchrge.Text = tour_charge2.ToString();

                    if (Kms >= 200)
                    {
                        extra_km = (Kms - Mak_km) * extrakmchrge;

                        int extra_km2 = extra_km;
                        txtextrkmfullchrge.Text = extra_km2.ToString();

                        tourcharge = tour_charge2 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge2 = twohundrekmpackrent;
                        txttourchrge.Text = tour_charge2.ToString();

                        tourcharge = tour_charge2 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    if (totalhour >= 13)
                    {
                        waiting = (totalhour - Max_hr) * chrgeforwaiting;

                        int waiting2 = waiting;
                        txtwaitingfullchrge.Text = waiting2.ToString();

                        tourcharge = tour_charge2 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge2 = twohundrekmpackrent;
                        txttourchrge.Text = tour_charge2.ToString();

                        tourcharge = tour_charge2 + extra_km + waiting;
                        txttotal.Text = tourcharge.ToString();
                    }
                }
                    if (package == "Airportdrop")
                    {
                        Mak_km = 50;
                        Max_hr = 2;
                        int tour_charge3 = 50*kmcharge;
                        txttourchrge.Text = tour_charge3.ToString();
                        if (Kms >= 50)
                        {
                            extra_km = (Kms - Mak_km) * extrakmchrge;

                            int extra_km3 = extra_km;
                            txtextrkmfullchrge.Text = extra_km3.ToString();

                            tourcharge = tour_charge3 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        else
                        {
                            tour_charge3 = 50*kmcharge;
                            txttourchrge.Text = tour_charge3.ToString();

                            tourcharge = tour_charge3 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        if (totalhour >= 2)
                        {
                            waiting = (totalhour - Max_hr) * chrgeforwaiting;

                            int waiting3 = waiting;
                            txtwaitingfullchrge.Text = waiting3.ToString();

                            tourcharge = tour_charge3 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        else
                        {
                            tour_charge3 = 50*kmcharge;
                            txttourchrge.Text = tour_charge3.ToString();

                            tourcharge = tour_charge3 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }

                    }
                    if (package == "Airportpickup")
                    {
                        Mak_km = 50;
                        Max_hr = 2;
                        int tour_charge4 = 50 * kmcharge;
                        txttourchrge.Text = tour_charge4.ToString();
                        if (Kms >= 50)
                        {
                            extra_km = (Kms - Mak_km) * extrakmchrge;

                            int extra_km4 = extra_km;
                            txtextrkmfullchrge.Text = extra_km4.ToString();

                            tourcharge = tour_charge4 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        else
                        {
                            tour_charge4 = 50 * kmcharge;
                            txttourchrge.Text = tour_charge4.ToString();

                            tourcharge = tour_charge4 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        if (totalhour >= 2)
                        {
                            waiting = (totalhour - Max_hr) * chrgeforwaiting;

                            int waiting4 = waiting;
                            txtwaitingfullchrge.Text = waiting4.ToString();

                            tourcharge = tour_charge4 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }
                        else
                        {
                            tour_charge4 = 50 * kmcharge;
                            txttourchrge.Text = tour_charge4.ToString();

                            tourcharge = tour_charge4 + extra_km + waiting;
                            txttotal.Text = tourcharge.ToString();
                        }

                    }
                
            }
                con.Close();
                return tourcharge;
            }


        private void savebtn_Click(object sender, EventArgs e)
        {
            if (txtbxdayrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                daytourid = int.Parse(txtbxdayrentid.Text);
                customename = txtbxcustomer.Text;
                phonenumber = txtnumber.Text;
                vhclid = int.Parse(cmbvehcl.Text);
                packages = cmbpack.Text;
                strtdate = dtpstart.Value.Date;
                enddate = dtpend.Value.Date;
                startkm = txtstrtrdng.Text;
                endkm = txtendrdng.Text;
                vehiclecharge = txttourchrge.Text;
                extrakmchrge = txtextrkmfullchrge.Text;
                waitingcharge = txtwaitingfullchrge.Text;
                total = txttotal.Text;

                con.Open();
                string insert = "insert into Table_Day_tour values('" + daytourid + "','" + customename + "','" + phonenumber + "','" + vhclid + "','" +
                    packages + "','" + strtdate + "','" + enddate + "','" + startkm + "','" + endkm + "','" + vehiclecharge + "','" +
                    extrakmchrge + "','" + waitingcharge + "','" + total + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Successfully Save", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();




            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (txtbxdayrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                daytourid = int.Parse(txtbxdayrentid.Text);
                customename = txtbxcustomer.Text;
                phonenumber = txtnumber.Text;
                vhclid = int.Parse(cmbvehcl.Text);
                packages = cmbpack.Text;
                strtdate = dtpstart.Value.Date;
                enddate = dtpend.Value.Date;
                startkm = txtstrtrdng.Text;
                endkm = txtendrdng.Text;
                vehiclecharge = txttourchrge.Text;
                extrakmchrge = txtextrkmfullchrge.Text;
                waitingcharge = txtwaitingfullchrge.Text;
                total = txttotal.Text;

                string update = "update Table_Day_tour set Customer_name ='" + customename + "',Phone_no = '" + phonenumber + "',Rent_vehicle_id = '" + vhclid + "',packages = '" + packages + "',Tour_start_date = '" + strtdate + "',Tour_end_date = '" + enddate + "',Startkm = '" + startkm + "',Endkm = '" + endkm + "',Tour_charge = '" + vehiclecharge + "',Extrakm_charge = '" + extrakmchrge + "',Waiting_charge = '" + waitingcharge + "',Total = '" + total + "' where Daytour_id = '" + daytourid + "'";
                if (MessageBox.Show("Are you going to update?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated");
                    con.Close();

                }


            }
        }
        private void dltbtn_Click(object sender, EventArgs e)
        {
            if (txtbxdayrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                string delete = "Delete from Table_Day_tour  where Daytour_id = '" + daytourid + "' ";
                SqlCommand cmd = new SqlCommand(delete, con);

                if (MessageBox.Show("Are you want to delete a exisisting record?", "confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Deleted Sucessfuly", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
            }
        }
        private void srchbtn_Click(object sender, EventArgs e)
        {
            if (txtbxdayrentid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                daytourid = int.Parse(txtbxdayrentid.Text);
                string search = "Select *from Table_Day_tour  where Daytour_id='" + daytourid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    txtbxcustomer.Text = r["Customer_name"].ToString();
                    txtnumber.Text = r["Phone_no"].ToString();
                    cmbvehcl.Text = r["Rent_vehicle_id"].ToString();
                    cmbpack.Text = r["packages"].ToString();
                    dtpstart.Text = r["Tour_start_date"].ToString();
                    dtpend.Text = r["Tour_end_date"].ToString();
                    txtstrtrdng.Text = r["Startkm"].ToString();
                    txtendrdng.Text = r["Endkm"].ToString();
                    txttourchrge.Text = r["Tour_charge"].ToString();
                    txtextrkmfullchrge.Text = r["Extrakm_charge"].ToString();
                    txtwaitingfullchrge.Text = r["Waiting_charge"].ToString();
                    txttotal.Text = r["Total"].ToString();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            txtbxdayrentid.Clear();
            txtbxcustomer.Clear();
            txtnumber.Clear();
            cmbvehcl.ResetText();
            cmbpack.ResetText();
            dtpstart.ResetText();
            dtpend.ResetText();
            txtstrtrdng.Clear();
            txtendrdng.Clear();
            txttourchrge.Clear();
            txtextrkmfullchrge.Clear();
            txtwaitingfullchrge.Clear();
            txttotal.Clear();

        }

        private void btnview_Click(object sender, EventArgs e)
        {
            chart = new SqlDataAdapter("Select * from Table_Day_tour ", con);
            dt = new DataTable();
            chart.Fill(dt);
            dataGridView1.DataSource = dt;

            pictureBox1.Visible = false;
            dataGridView1.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.dataGridView1.Refresh();
            this.dataGridView1.Parent.Refresh();
        }


    }
}







                    
        
    

