﻿namespace WindowsFormsApplication2
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            this.label1 = new System.Windows.Forms.Label();
            this.extbtn = new System.Windows.Forms.Button();
            this.srchbtn = new System.Windows.Forms.Button();
            this.dltbtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.savebtn = new System.Windows.Forms.Button();
            this.lbllngid = new System.Windows.Forms.Label();
            this.lblvehcl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtnitpark = new System.Windows.Forms.TextBox();
            this.txtnitstay = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btncalculate = new System.Windows.Forms.Button();
            this.txttotalchrge = new System.Windows.Forms.TextBox();
            this.txtextrkmchrge = new System.Windows.Forms.TextBox();
            this.txttourchrge = new System.Windows.Forms.TextBox();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lbttourchrge = new System.Windows.Forms.Label();
            this.lblextrkmcharge = new System.Windows.Forms.Label();
            this.cmbpackage = new System.Windows.Forms.ComboBox();
            this.txtendkm = new System.Windows.Forms.TextBox();
            this.txtstartkm = new System.Windows.Forms.TextBox();
            this.lblendkm = new System.Windows.Forms.Label();
            this.lblstrtkm = new System.Windows.Forms.Label();
            this.lblendtym = new System.Windows.Forms.Label();
            this.lblstrttym = new System.Windows.Forms.Label();
            this.lblpckge = new System.Windows.Forms.Label();
            this.txtlongid = new System.Windows.Forms.TextBox();
            this.cmbvehcl = new System.Windows.Forms.ComboBox();
            this.btnhme = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblnmber = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblnitstay = new System.Windows.Forms.Label();
            this.txtnitparking = new System.Windows.Forms.TextBox();
            this.txtnightstay = new System.Windows.Forms.TextBox();
            this.ayuboDataSet = new WindowsFormsApplication2.AyuboDataSet();
            this.tableLongtourBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.table_Long_tourTableAdapter = new WindowsFormsApplication2.AyuboDataSetTableAdapters.Table_Long_tourTableAdapter();
            this.dtstart = new System.Windows.Forms.DateTimePicker();
            this.dtpend = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnview = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ayuboDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableLongtourBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(522, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "Long Tour";
            // 
            // extbtn
            // 
            this.extbtn.BackColor = System.Drawing.Color.DarkRed;
            this.extbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.extbtn.Location = new System.Drawing.Point(1100, 746);
            this.extbtn.Name = "extbtn";
            this.extbtn.Size = new System.Drawing.Size(111, 40);
            this.extbtn.TabIndex = 8;
            this.extbtn.Text = "Exit";
            this.extbtn.UseVisualStyleBackColor = false;
            this.extbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // srchbtn
            // 
            this.srchbtn.BackColor = System.Drawing.Color.DarkRed;
            this.srchbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.srchbtn.Location = new System.Drawing.Point(504, 746);
            this.srchbtn.Name = "srchbtn";
            this.srchbtn.Size = new System.Drawing.Size(112, 40);
            this.srchbtn.TabIndex = 6;
            this.srchbtn.Text = "Search";
            this.srchbtn.UseVisualStyleBackColor = false;
            this.srchbtn.Click += new System.EventHandler(this.srchbtn_Click);
            // 
            // dltbtn
            // 
            this.dltbtn.BackColor = System.Drawing.Color.DarkRed;
            this.dltbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dltbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.dltbtn.Location = new System.Drawing.Point(362, 746);
            this.dltbtn.Name = "dltbtn";
            this.dltbtn.Size = new System.Drawing.Size(112, 40);
            this.dltbtn.TabIndex = 5;
            this.dltbtn.Text = "Delete";
            this.dltbtn.UseVisualStyleBackColor = false;
            this.dltbtn.Click += new System.EventHandler(this.dltbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.DarkRed;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.updatebtn.Location = new System.Drawing.Point(212, 746);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(112, 40);
            this.updatebtn.TabIndex = 4;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = false;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // savebtn
            // 
            this.savebtn.BackColor = System.Drawing.Color.DarkRed;
            this.savebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.savebtn.Location = new System.Drawing.Point(57, 746);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(112, 40);
            this.savebtn.TabIndex = 3;
            this.savebtn.Text = "Save";
            this.savebtn.UseVisualStyleBackColor = false;
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // lbllngid
            // 
            this.lbllngid.AutoSize = true;
            this.lbllngid.BackColor = System.Drawing.Color.Transparent;
            this.lbllngid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbllngid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllngid.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbllngid.Location = new System.Drawing.Point(44, 81);
            this.lbllngid.Name = "lbllngid";
            this.lbllngid.Size = new System.Drawing.Size(134, 24);
            this.lbllngid.TabIndex = 39;
            this.lbllngid.Text = "Long_Tour_ID";
            // 
            // lblvehcl
            // 
            this.lblvehcl.AutoSize = true;
            this.lblvehcl.BackColor = System.Drawing.Color.Transparent;
            this.lblvehcl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblvehcl.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehcl.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblvehcl.Location = new System.Drawing.Point(44, 278);
            this.lblvehcl.Name = "lblvehcl";
            this.lblvehcl.Size = new System.Drawing.Size(146, 24);
            this.lblvehcl.TabIndex = 40;
            this.lblvehcl.Text = "Rent_Vehicle_Id";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.txtnitpark);
            this.panel1.Controls.Add(this.txtnitstay);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btncalculate);
            this.panel1.Controls.Add(this.txttotalchrge);
            this.panel1.Controls.Add(this.txtextrkmchrge);
            this.panel1.Controls.Add(this.txttourchrge);
            this.panel1.Controls.Add(this.lbltotal);
            this.panel1.Controls.Add(this.lbttourchrge);
            this.panel1.Controls.Add(this.lblextrkmcharge);
            this.panel1.Location = new System.Drawing.Point(740, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(488, 344);
            this.panel1.TabIndex = 57;
            // 
            // txtnitpark
            // 
            this.txtnitpark.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnitpark.Location = new System.Drawing.Point(291, 169);
            this.txtnitpark.Multiline = true;
            this.txtnitpark.Name = "txtnitpark";
            this.txtnitpark.ReadOnly = true;
            this.txtnitpark.Size = new System.Drawing.Size(180, 37);
            this.txtnitpark.TabIndex = 86;
            this.txtnitpark.Text = "0.00";
            // 
            // txtnitstay
            // 
            this.txtnitstay.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnitstay.Location = new System.Drawing.Point(291, 126);
            this.txtnitstay.Multiline = true;
            this.txtnitstay.Name = "txtnitstay";
            this.txtnitstay.ReadOnly = true;
            this.txtnitstay.Size = new System.Drawing.Size(180, 37);
            this.txtnitstay.TabIndex = 85;
            this.txtnitstay.Text = "0.00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label4.Location = new System.Drawing.Point(24, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 25);
            this.label4.TabIndex = 84;
            this.label4.Text = "Night park";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label3.Location = new System.Drawing.Point(24, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 25);
            this.label3.TabIndex = 83;
            this.label3.Text = "Over Night Stay Charge";
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.DarkRed;
            this.btncalculate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.ForeColor = System.Drawing.SystemColors.Control;
            this.btncalculate.Location = new System.Drawing.Point(198, 273);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(144, 40);
            this.btncalculate.TabIndex = 1;
            this.btncalculate.Text = "Calculate";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // txttotalchrge
            // 
            this.txttotalchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotalchrge.Location = new System.Drawing.Point(291, 215);
            this.txttotalchrge.Multiline = true;
            this.txttotalchrge.Name = "txttotalchrge";
            this.txttotalchrge.ReadOnly = true;
            this.txttotalchrge.Size = new System.Drawing.Size(180, 37);
            this.txttotalchrge.TabIndex = 82;
            this.txttotalchrge.Text = "0.00";
            // 
            // txtextrkmchrge
            // 
            this.txtextrkmchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtextrkmchrge.Location = new System.Drawing.Point(291, 79);
            this.txtextrkmchrge.Multiline = true;
            this.txtextrkmchrge.Name = "txtextrkmchrge";
            this.txtextrkmchrge.ReadOnly = true;
            this.txtextrkmchrge.Size = new System.Drawing.Size(180, 37);
            this.txtextrkmchrge.TabIndex = 81;
            this.txtextrkmchrge.Text = "0.00";
            // 
            // txttourchrge
            // 
            this.txttourchrge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttourchrge.Location = new System.Drawing.Point(291, 28);
            this.txttourchrge.Multiline = true;
            this.txttourchrge.Name = "txttourchrge";
            this.txttourchrge.ReadOnly = true;
            this.txttourchrge.Size = new System.Drawing.Size(180, 37);
            this.txttourchrge.TabIndex = 78;
            this.txttourchrge.Text = "0.00";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.BackColor = System.Drawing.Color.Transparent;
            this.lbltotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbltotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lbltotal.Location = new System.Drawing.Point(24, 215);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(55, 25);
            this.lbltotal.TabIndex = 52;
            this.lbltotal.Text = "Total";
            // 
            // lbttourchrge
            // 
            this.lbttourchrge.AutoSize = true;
            this.lbttourchrge.BackColor = System.Drawing.Color.Transparent;
            this.lbttourchrge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbttourchrge.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbttourchrge.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lbttourchrge.Location = new System.Drawing.Point(24, 31);
            this.lbttourchrge.Name = "lbttourchrge";
            this.lbttourchrge.Size = new System.Drawing.Size(123, 25);
            this.lbttourchrge.TabIndex = 48;
            this.lbttourchrge.Text = "Tour_Charge";
            // 
            // lblextrkmcharge
            // 
            this.lblextrkmcharge.AutoSize = true;
            this.lblextrkmcharge.BackColor = System.Drawing.Color.Transparent;
            this.lblextrkmcharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblextrkmcharge.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblextrkmcharge.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lblextrkmcharge.Location = new System.Drawing.Point(24, 80);
            this.lblextrkmcharge.Name = "lblextrkmcharge";
            this.lblextrkmcharge.Size = new System.Drawing.Size(171, 25);
            this.lblextrkmcharge.TabIndex = 49;
            this.lblextrkmcharge.Text = "Extra_Km_Charge";
            // 
            // cmbpackage
            // 
            this.cmbpackage.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbpackage.FormattingEnabled = true;
            this.cmbpackage.Items.AddRange(new object[] {
            "300 Km Tour",
            "400 Km Tour"});
            this.cmbpackage.Location = new System.Drawing.Point(315, 329);
            this.cmbpackage.Name = "cmbpackage";
            this.cmbpackage.Size = new System.Drawing.Size(180, 28);
            this.cmbpackage.TabIndex = 76;
            // 
            // txtendkm
            // 
            this.txtendkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtendkm.Location = new System.Drawing.Point(315, 542);
            this.txtendkm.Multiline = true;
            this.txtendkm.Name = "txtendkm";
            this.txtendkm.Size = new System.Drawing.Size(180, 37);
            this.txtendkm.TabIndex = 73;
            // 
            // txtstartkm
            // 
            this.txtstartkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartkm.Location = new System.Drawing.Point(315, 490);
            this.txtstartkm.Multiline = true;
            this.txtstartkm.Name = "txtstartkm";
            this.txtstartkm.Size = new System.Drawing.Size(180, 37);
            this.txtstartkm.TabIndex = 72;
            this.txtstartkm.TextChanged += new System.EventHandler(this.txtstartkm_TextChanged);
            // 
            // lblendkm
            // 
            this.lblendkm.AutoSize = true;
            this.lblendkm.BackColor = System.Drawing.Color.Transparent;
            this.lblendkm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblendkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblendkm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblendkm.Location = new System.Drawing.Point(43, 545);
            this.lblendkm.Name = "lblendkm";
            this.lblendkm.Size = new System.Drawing.Size(162, 24);
            this.lblendkm.TabIndex = 71;
            this.lblendkm.Text = "End_Km_Reading";
            // 
            // lblstrtkm
            // 
            this.lblstrtkm.AutoSize = true;
            this.lblstrtkm.BackColor = System.Drawing.Color.Transparent;
            this.lblstrtkm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblstrtkm.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstrtkm.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblstrtkm.Location = new System.Drawing.Point(43, 493);
            this.lblstrtkm.Name = "lblstrtkm";
            this.lblstrtkm.Size = new System.Drawing.Size(170, 24);
            this.lblstrtkm.TabIndex = 70;
            this.lblstrtkm.Text = "Start_Km_Reading";
            // 
            // lblendtym
            // 
            this.lblendtym.AutoSize = true;
            this.lblendtym.BackColor = System.Drawing.Color.Transparent;
            this.lblendtym.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblendtym.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblendtym.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblendtym.Location = new System.Drawing.Point(44, 440);
            this.lblendtym.Name = "lblendtym";
            this.lblendtym.Size = new System.Drawing.Size(148, 24);
            this.lblendtym.TabIndex = 69;
            this.lblendtym.Text = "Tour_End_TIme";
            // 
            // lblstrttym
            // 
            this.lblstrttym.AutoSize = true;
            this.lblstrttym.BackColor = System.Drawing.Color.Transparent;
            this.lblstrttym.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblstrttym.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstrttym.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblstrttym.Location = new System.Drawing.Point(43, 389);
            this.lblstrttym.Name = "lblstrttym";
            this.lblstrttym.Size = new System.Drawing.Size(154, 24);
            this.lblstrttym.TabIndex = 68;
            this.lblstrttym.Text = "Tour_Start_Time";
            // 
            // lblpckge
            // 
            this.lblpckge.AutoSize = true;
            this.lblpckge.BackColor = System.Drawing.Color.Transparent;
            this.lblpckge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpckge.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpckge.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblpckge.Location = new System.Drawing.Point(44, 333);
            this.lblpckge.Name = "lblpckge";
            this.lblpckge.Size = new System.Drawing.Size(91, 24);
            this.lblpckge.TabIndex = 67;
            this.lblpckge.Text = "Packages";
            // 
            // txtlongid
            // 
            this.txtlongid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlongid.Location = new System.Drawing.Point(315, 78);
            this.txtlongid.Multiline = true;
            this.txtlongid.Name = "txtlongid";
            this.txtlongid.Size = new System.Drawing.Size(183, 40);
            this.txtlongid.TabIndex = 77;
            // 
            // cmbvehcl
            // 
            this.cmbvehcl.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbvehcl.FormattingEnabled = true;
            this.cmbvehcl.Location = new System.Drawing.Point(315, 274);
            this.cmbvehcl.Name = "cmbvehcl";
            this.cmbvehcl.Size = new System.Drawing.Size(180, 28);
            this.cmbvehcl.TabIndex = 78;
            this.cmbvehcl.SelectedIndexChanged += new System.EventHandler(this.cmbvehcl_SelectedIndexChanged);
            // 
            // btnhme
            // 
            this.btnhme.BackColor = System.Drawing.Color.DarkRed;
            this.btnhme.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhme.ForeColor = System.Drawing.SystemColors.Control;
            this.btnhme.Location = new System.Drawing.Point(1100, 15);
            this.btnhme.Name = "btnhme";
            this.btnhme.Size = new System.Drawing.Size(111, 40);
            this.btnhme.TabIndex = 7;
            this.btnhme.Text = "Home";
            this.btnhme.UseVisualStyleBackColor = false;
            this.btnhme.Click += new System.EventHandler(this.btnhme_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.DarkRed;
            this.clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.ForeColor = System.Drawing.SystemColors.Control;
            this.clear.Location = new System.Drawing.Point(646, 746);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(112, 40);
            this.clear.TabIndex = 83;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtnumber
            // 
            this.txtnumber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumber.Location = new System.Drawing.Point(315, 194);
            this.txtnumber.Multiline = true;
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(180, 37);
            this.txtnumber.TabIndex = 87;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(315, 134);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(180, 40);
            this.txtname.TabIndex = 86;
            // 
            // lblnmber
            // 
            this.lblnmber.AutoSize = true;
            this.lblnmber.BackColor = System.Drawing.Color.Transparent;
            this.lblnmber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblnmber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnmber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblnmber.Location = new System.Drawing.Point(43, 194);
            this.lblnmber.Name = "lblnmber";
            this.lblnmber.Size = new System.Drawing.Size(92, 24);
            this.lblnmber.TabIndex = 85;
            this.lblnmber.Text = "Phone No";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.BackColor = System.Drawing.Color.Transparent;
            this.lblcustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcustomer.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcustomer.Location = new System.Drawing.Point(45, 137);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(145, 24);
            this.lblcustomer.TabIndex = 84;
            this.lblcustomer.Text = "Customer Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(43, 639);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 24);
            this.label2.TabIndex = 89;
            this.label2.Text = "Night Parking Charge";
            // 
            // lblnitstay
            // 
            this.lblnitstay.AutoSize = true;
            this.lblnitstay.BackColor = System.Drawing.Color.Transparent;
            this.lblnitstay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblnitstay.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnitstay.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblnitstay.Location = new System.Drawing.Point(43, 595);
            this.lblnitstay.Name = "lblnitstay";
            this.lblnitstay.Size = new System.Drawing.Size(210, 24);
            this.lblnitstay.TabIndex = 90;
            this.lblnitstay.Text = "Over Night Stay Charge";
            // 
            // txtnitparking
            // 
            this.txtnitparking.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnitparking.Location = new System.Drawing.Point(315, 639);
            this.txtnitparking.Multiline = true;
            this.txtnitparking.Name = "txtnitparking";
            this.txtnitparking.Size = new System.Drawing.Size(180, 37);
            this.txtnitparking.TabIndex = 91;
            this.txtnitparking.Text = "00";
            // 
            // txtnightstay
            // 
            this.txtnightstay.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnightstay.Location = new System.Drawing.Point(315, 592);
            this.txtnightstay.Multiline = true;
            this.txtnightstay.Name = "txtnightstay";
            this.txtnightstay.Size = new System.Drawing.Size(180, 37);
            this.txtnightstay.TabIndex = 92;
            this.txtnightstay.Text = "00";
            // 
            // ayuboDataSet
            // 
            this.ayuboDataSet.DataSetName = "AyuboDataSet";
            this.ayuboDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableLongtourBindingSource
            // 
            this.tableLongtourBindingSource.DataMember = "Table_Long_tour";
            this.tableLongtourBindingSource.DataSource = this.ayuboDataSet;
            // 
            // table_Long_tourTableAdapter
            // 
            this.table_Long_tourTableAdapter.ClearBeforeFill = true;
            // 
            // dtstart
            // 
            this.dtstart.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtstart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtstart.Location = new System.Drawing.Point(315, 385);
            this.dtstart.Name = "dtstart";
            this.dtstart.Size = new System.Drawing.Size(180, 28);
            this.dtstart.TabIndex = 93;
            // 
            // dtpend
            // 
            this.dtpend.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpend.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpend.Location = new System.Drawing.Point(315, 436);
            this.dtpend.Name = "dtpend";
            this.dtpend.Size = new System.Drawing.Size(180, 28);
            this.dtpend.TabIndex = 94;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(729, 446);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(499, 275);
            this.dataGridView1.TabIndex = 96;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(729, 446);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(499, 275);
            this.pictureBox1.TabIndex = 95;
            this.pictureBox1.TabStop = false;
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkRed;
            this.btnview.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.SystemColors.Control;
            this.btnview.Location = new System.Drawing.Point(775, 746);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(112, 40);
            this.btnview.TabIndex = 97;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1240, 798);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dtpend);
            this.Controls.Add(this.dtstart);
            this.Controls.Add(this.txtnightstay);
            this.Controls.Add(this.txtnitparking);
            this.Controls.Add(this.lblnitstay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtnumber);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblnmber);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.btnhme);
            this.Controls.Add(this.cmbvehcl);
            this.Controls.Add(this.txtlongid);
            this.Controls.Add(this.cmbpackage);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtendkm);
            this.Controls.Add(this.txtstartkm);
            this.Controls.Add(this.lblendkm);
            this.Controls.Add(this.lblvehcl);
            this.Controls.Add(this.lblstrtkm);
            this.Controls.Add(this.lbllngid);
            this.Controls.Add(this.lblendtym);
            this.Controls.Add(this.lblstrttym);
            this.Controls.Add(this.srchbtn);
            this.Controls.Add(this.lblpckge);
            this.Controls.Add(this.dltbtn);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.savebtn);
            this.Controls.Add(this.extbtn);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Long Tour";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ayuboDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableLongtourBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button extbtn;
        private System.Windows.Forms.Button srchbtn;
        private System.Windows.Forms.Button dltbtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button savebtn;
        private System.Windows.Forms.Label lbllngid;
        private System.Windows.Forms.Label lblvehcl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lbttourchrge;
        private System.Windows.Forms.Label lblextrkmcharge;
        private System.Windows.Forms.ComboBox cmbpackage;
        private System.Windows.Forms.TextBox txtendkm;
        private System.Windows.Forms.TextBox txtstartkm;
        private System.Windows.Forms.Label lblendkm;
        private System.Windows.Forms.Label lblstrtkm;
        private System.Windows.Forms.Label lblendtym;
        private System.Windows.Forms.Label lblstrttym;
        private System.Windows.Forms.Label lblpckge;
        private System.Windows.Forms.TextBox txtlongid;
        private System.Windows.Forms.ComboBox cmbvehcl;
        private System.Windows.Forms.TextBox txttotalchrge;
        private System.Windows.Forms.TextBox txtextrkmchrge;
        private System.Windows.Forms.TextBox txttourchrge;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Button btnhme;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.TextBox txtnumber;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblnmber;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblnitstay;
        private System.Windows.Forms.TextBox txtnitparking;
        private System.Windows.Forms.TextBox txtnightstay;
        private AyuboDataSet ayuboDataSet;
        private System.Windows.Forms.BindingSource tableLongtourBindingSource;
        private AyuboDataSetTableAdapters.Table_Long_tourTableAdapter table_Long_tourTableAdapter;
        private System.Windows.Forms.TextBox txtnitpark;
        private System.Windows.Forms.TextBox txtnitstay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtstart;
        private System.Windows.Forms.DateTimePicker dtpend;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnview;
    }
}