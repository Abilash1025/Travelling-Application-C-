﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            FillComboBox();
        }

        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=Ayubo;Integrated Security=True";
        int tourcharge, Max_km, Max_days, Over_night, Over_night1, Over_night2, vehicle_park, vehicle_park1, vehicle_park2, extra_km, Extrakm_1, Extrakm_2, overnightcharge, kms, vehicleparkcharge;
        int longtourid, vhclid;
        string customername, phonenumber, packages, strtkm, endkm,overnitchargeperday,latenitparkchrgeperday, vhclchrge, extrmkmchrge, ovrnitchrge, nitprkchrge, ttlchrge;
        DateTime strtdate, enddate;
        SqlConnection con = new SqlConnection(connection);
        SqlDataAdapter chart;
        DataTable dt;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cmbvehcl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void FillComboBox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select V_Name from Table_ADD1", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbvehcl.DataSource = dt;
            cmbvehcl.DisplayMember = "V_Name";
            cmbvehcl.ValueMember = "V_Name";

        }

        private void btnhme_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            this.Hide();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {

            DateTime strt = dtstart.Value;
            DateTime end = dtpend.Value;
            string package = cmbpackage.SelectedItem.ToString();
            string vehicle = cmbvehcl.SelectedItem.ToString();
            string strtkm = txtstartkm.Text;
            string endkm = txtendkm.Text;

            rentcalculation(strt, end, package, vehicle, strtkm, endkm);
        }

        private int rentcalculation(DateTime start, DateTime end, string package,string vehicle,string startkm, string endkm)
        {
            SqlCommand cmd = new SqlCommand("select* from Table_ADD1", con);
            cmd.Parameters.AddWithValue("@001", vehicle);

            con.Open();

            SqlDataReader r = cmd.ExecuteReader();

            if (r.Read())
            {
                int threehundredkmpackrent = int.Parse(r["threehundredkm"].ToString());
                int fourhundredkmpackrent = int.Parse(r["fourhundredkm"].ToString());
                int extrakmcharge = int.Parse(r["Extrakm_charge"].ToString());
                overnightcharge = int.Parse(txtnightstay.Text);
                vehicleparkcharge = int.Parse(txtnitparking.Text);
                TimeSpan ts = end.Date - start.Date;
                int days = ts.Days + 1;
                kms = int.Parse(txtendkm.Text) - int.Parse(txtstartkm.Text);

                if (package == "300 Km Tour")
                {
                    Max_km = 300;
                    Max_days = 2;

                    int tour_charge1 = threehundredkmpackrent;
                    txttourchrge.Text = tour_charge1.ToString();

                    if (days >= Max_days)
                    {
                        Over_night = (days - Max_days) * overnightcharge;
                        vehicle_park = (days - Max_days) * vehicleparkcharge;

                        Over_night1 = Over_night;
                        txtnitstay.Text = Over_night1.ToString();

                        vehicle_park1 = vehicle_park;
                        txtnitpark.Text = vehicle_park.ToString();

                        tourcharge = tour_charge1 + Over_night1 + vehicle_park1 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge1 = threehundredkmpackrent;
                        txttourchrge.Text = tour_charge1.ToString();

                        tourcharge = tour_charge1 + Over_night1 + vehicle_park1 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }

                    if (kms >= Max_km)
                    {
                        Extrakm_1 = (kms - Max_km) * extrakmcharge;

                        extra_km = Extrakm_1;
                        txtextrkmchrge.Text = Extrakm_1.ToString();

                        tourcharge = tour_charge1 + Over_night1 + vehicle_park1 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }
                    else
                    {
                        tour_charge1 = threehundredkmpackrent;
                        txttourchrge.Text = tour_charge1.ToString();

                        tourcharge = tour_charge1 + Over_night1 + vehicle_park1 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }
                }

                if (package == "400 Km Tour")
                {
                    Max_km = 400;
                    Max_days = 4;

                    int tour_charge2 = fourhundredkmpackrent;
                    txttourchrge.Text = tour_charge2.ToString();

                    if (days >= Max_days)
                    {
                        Over_night = (days - Max_days) * overnightcharge;
                        vehicle_park = (days - Max_days) * vehicleparkcharge;

                        Over_night2 = Over_night;
                        txtnitstay.Text = Over_night2.ToString();

                        vehicle_park2 = vehicle_park;
                        txtnitpark.Text = vehicle_park.ToString();

                        tourcharge = tour_charge2 + Over_night2 + vehicle_park2 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }

                    else
                    {
                        tour_charge2 = fourhundredkmpackrent;
                        txttourchrge.Text = tour_charge2.ToString();

                        tourcharge = tour_charge2 + Over_night2 + vehicle_park2 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }

                    if (kms >= Max_km)
                    {
                        Extrakm_2 = (kms - Max_km) * extrakmcharge;

                        extra_km = Extrakm_2;
                        txtextrkmchrge.Text = Extrakm_2.ToString();

                        tourcharge = tour_charge2 + Over_night2 + vehicle_park2 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }

                    else
                    {
                        tour_charge2 = fourhundredkmpackrent;
                        txttourchrge.Text = tour_charge2.ToString();

                        tourcharge = tour_charge2 + Over_night2 + vehicle_park2 + extra_km;
                        txttotalchrge.Text = tourcharge.ToString();
                    }
                }
            }

            con.Close();

            return tourcharge;
        }

        private void savebtn_Click(object sender, EventArgs e)
        {
            if(txtlongid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
            longtourid = int.Parse(txtlongid.Text);
            customername = txtname.Text;
            phonenumber = txtnumber.Text;
            vhclid = int.Parse(cmbvehcl.Text);
            packages = cmbpackage.Text;
            strtdate = dtstart.Value.Date;
            enddate = dtpend.Value.Date;
            strtkm = txtstartkm.Text;
            endkm = txtendkm.Text;  
            overnitchargeperday = txtnightstay.Text;
            latenitparkchrgeperday = txtnitparking.Text;
            vhclchrge = txttourchrge.Text;
            extrmkmchrge = txtextrkmchrge.Text;
            ovrnitchrge = txtnitstay.Text;
            nitprkchrge = txtnitpark.Text;
            ttlchrge = txttotalchrge.Text;

            con.Open();

            string insert = "Insert into Table_Long_tour values('" + longtourid + "','" + customername + "','" + phonenumber + "','" +
                vhclid + "','" + packages + "','" + strtdate + "','" + enddate + "','"+ overnitchargeperday +"','"+ latenitparkchrgeperday +"','" + 
                strtkm + "','" + endkm + "','" + vhclchrge + "','"+ extrmkmchrge +"','" + ovrnitchrge + "','" + nitprkchrge + "','" + ttlchrge + "')";
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Successfully Save", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();


        }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (txtlongid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                longtourid = int.Parse(txtlongid.Text);
                customername = txtname.Text;
                phonenumber = txtnumber.Text;
                vhclid = int.Parse(cmbvehcl.Text);
                packages = cmbpackage.Text;
                strtdate = dtstart.Value.Date;
                enddate = dtpend.Value.Date;
                strtkm = txtstartkm.Text;
                endkm = txtendkm.Text;
                overnitchargeperday = txtnightstay.Text;
                latenitparkchrgeperday = txtnitparking.Text;
                vhclchrge = txttourchrge.Text;
                extrmkmchrge = txtextrkmchrge.Text;
                ovrnitchrge = txtnitstay.Text;
                nitprkchrge = txtnitpark.Text;
                ttlchrge = txttotalchrge.Text;

                string update = "update Table_Long_tour set Customer_name ='" + customername + "', Phone_no ='" + phonenumber + "',Rent_vehicle_id = '" +
                    vhclid + "',packages = '" + packages + "',Tour_start_date = '" + strtdate + "',Tour_end_date = '" + enddate + "',Startkm = '" +
                    strtkm + "',Endkm = '" + endkm + "',overnitstayperday = '" + overnitchargeperday + "',latenitparkperday = '" +
                    latenitparkchrgeperday + "', Tour_charge = '" + vhclchrge + "',Extra_km_charge = '" + extrmkmchrge + "', Latenight_stay_charge = '" +
                    ovrnitchrge + "',Nitpark_chrge = '" + nitprkchrge + "',Total = '" + ttlchrge + "' where Longtour_id = '" + longtourid + "' ";

                if (MessageBox.Show("Are you going to update?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated");
                    con.Close();

                }


            }
        }

        private void dltbtn_Click(object sender, EventArgs e)
        {
            if (txtlongid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                string delete = "Delete from Table_Long_tour where Longtour_id = '" + longtourid + "' ";
                SqlCommand cmd = new SqlCommand(delete, con);

                if (MessageBox.Show("Are you want to delete a exisisting record?", "confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Deleted Sucessfuly", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
            }
        }

        private void srchbtn_Click(object sender, EventArgs e)
        {
            if (txtlongid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                longtourid = int.Parse(txtlongid.Text);
                string search = "select * from Table_Long_tour where Longtour_id = '" + longtourid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    txtname.Text = r["Customer_name"].ToString();
                    txtnumber.Text = r["Phone_no"].ToString();
                    cmbvehcl.Text = r["Rent_vehicle_id"].ToString();
                    cmbpackage.Text = r["packages"].ToString();
                    dtstart.Text = r["Tour_start_date"].ToString();
                    dtpend.Text = r["Tour_end_date"].ToString();
                    txtstartkm.Text = r["Startkm"].ToString();
                    txtendkm.Text = r["Endkm"].ToString();
                    txtnightstay.Text = r["overnitstayperday"].ToString();
                    txtnitparking.Text = r["latenitparkperday"].ToString();
                    txttourchrge.Text = r["Tour_charge"].ToString();
                    txtextrkmchrge.Text = r["Extra_km_charge"].ToString();
                    txtnitstay.Text = r["Latenight_stay_charge"].ToString();
                    txtnitpark.Text = r["Nitpark_chrge"].ToString();
                    txttotalchrge.Text = r["Total"].ToString();
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtlongid.Clear();
            txtname.Clear();
            txtnumber.Clear();
            cmbvehcl.ResetText();
            cmbpackage.ResetText();
            dtstart.ResetText();
            dtpend.ResetText();
            txtstartkm.Clear();
            txtendkm.Clear();
            txtnightstay.Clear();
            txtnitparking.Clear();
            txttourchrge.Clear();
            txtextrkmchrge.Clear();
            txtnitstay.Clear();
            txtnitpark.Clear();
            txttotalchrge.Clear();
        }

        private void txtstartkm_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnview_Click(object sender, EventArgs e)
        {
            chart = new SqlDataAdapter("Select * from Table_Long_tour ", con);
            dt = new DataTable();
            chart.Fill(dt);
            dataGridView1.DataSource = dt;

            pictureBox1.Visible = false;
            dataGridView1.Visible = true;

        }
    }
}

