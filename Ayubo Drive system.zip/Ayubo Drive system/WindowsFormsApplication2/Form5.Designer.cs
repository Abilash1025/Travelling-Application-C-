﻿namespace WindowsFormsApplication2
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.label1 = new System.Windows.Forms.Label();
            this.extbtn = new System.Windows.Forms.Button();
            this.srchbtn = new System.Windows.Forms.Button();
            this.dltbtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.savebtn = new System.Windows.Forms.Button();
            this.labelrntid = new System.Windows.Forms.Label();
            this.labelvehicle = new System.Windows.Forms.Label();
            this.labelRnteddate = new System.Windows.Forms.Label();
            this.labeldriver = new System.Windows.Forms.Label();
            this.labelrtrndate = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lblnmber = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncalculate = new System.Windows.Forms.Button();
            this.txtbxtotal = new System.Windows.Forms.TextBox();
            this.txtbxdrvrtotal = new System.Windows.Forms.TextBox();
            this.txtbxvhclpay = new System.Windows.Forms.TextBox();
            this.Total = new System.Windows.Forms.Label();
            this.labeldvr = new System.Windows.Forms.Label();
            this.labelvhcl = new System.Windows.Forms.Label();
            this.txtbxrentid = new System.Windows.Forms.TextBox();
            this.txtcustomer = new System.Windows.Forms.TextBox();
            this.txtbnumber = new System.Windows.Forms.TextBox();
            this.btnhme = new System.Windows.Forms.Button();
            this.bbtnclear = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rad_rentdriver = new System.Windows.Forms.RadioButton();
            this.rad_rent = new System.Windows.Forms.RadioButton();
            this.cmdvehicle = new System.Windows.Forms.ComboBox();
            this.dtprented = new System.Windows.Forms.DateTimePicker();
            this.dtpreturn = new System.Windows.Forms.DateTimePicker();
            this.btnview = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(533, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rent";
            // 
            // extbtn
            // 
            this.extbtn.BackColor = System.Drawing.Color.DarkRed;
            this.extbtn.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.extbtn.Location = new System.Drawing.Point(1157, 746);
            this.extbtn.Name = "extbtn";
            this.extbtn.Size = new System.Drawing.Size(111, 40);
            this.extbtn.TabIndex = 7;
            this.extbtn.Text = "Exit";
            this.extbtn.UseVisualStyleBackColor = false;
            this.extbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // srchbtn
            // 
            this.srchbtn.BackColor = System.Drawing.Color.DarkRed;
            this.srchbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srchbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.srchbtn.Location = new System.Drawing.Point(474, 746);
            this.srchbtn.Name = "srchbtn";
            this.srchbtn.Size = new System.Drawing.Size(112, 40);
            this.srchbtn.TabIndex = 6;
            this.srchbtn.Text = "Search";
            this.srchbtn.UseVisualStyleBackColor = false;
            this.srchbtn.Click += new System.EventHandler(this.srchbtn_Click);
            // 
            // dltbtn
            // 
            this.dltbtn.BackColor = System.Drawing.Color.DarkRed;
            this.dltbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dltbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.dltbtn.Location = new System.Drawing.Point(332, 746);
            this.dltbtn.Name = "dltbtn";
            this.dltbtn.Size = new System.Drawing.Size(112, 40);
            this.dltbtn.TabIndex = 5;
            this.dltbtn.Text = "Delete";
            this.dltbtn.UseVisualStyleBackColor = false;
            this.dltbtn.Click += new System.EventHandler(this.dltbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.BackColor = System.Drawing.Color.DarkRed;
            this.updatebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.updatebtn.Location = new System.Drawing.Point(182, 746);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(112, 40);
            this.updatebtn.TabIndex = 4;
            this.updatebtn.Text = "Update";
            this.updatebtn.UseVisualStyleBackColor = false;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // savebtn
            // 
            this.savebtn.BackColor = System.Drawing.Color.DarkRed;
            this.savebtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebtn.ForeColor = System.Drawing.SystemColors.Control;
            this.savebtn.Location = new System.Drawing.Point(27, 746);
            this.savebtn.Name = "savebtn";
            this.savebtn.Size = new System.Drawing.Size(112, 40);
            this.savebtn.TabIndex = 3;
            this.savebtn.Text = "Save";
            this.savebtn.UseVisualStyleBackColor = false;
            this.savebtn.Click += new System.EventHandler(this.savebtn_Click);
            // 
            // labelrntid
            // 
            this.labelrntid.AutoSize = true;
            this.labelrntid.BackColor = System.Drawing.Color.Transparent;
            this.labelrntid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelrntid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelrntid.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelrntid.Location = new System.Drawing.Point(40, 92);
            this.labelrntid.Name = "labelrntid";
            this.labelrntid.Size = new System.Drawing.Size(77, 24);
            this.labelrntid.TabIndex = 37;
            this.labelrntid.Text = "Rent ID";
            // 
            // labelvehicle
            // 
            this.labelvehicle.AutoSize = true;
            this.labelvehicle.BackColor = System.Drawing.Color.Transparent;
            this.labelvehicle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelvehicle.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelvehicle.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelvehicle.Location = new System.Drawing.Point(40, 362);
            this.labelvehicle.Name = "labelvehicle";
            this.labelvehicle.Size = new System.Drawing.Size(146, 24);
            this.labelvehicle.TabIndex = 38;
            this.labelvehicle.Text = "Rent_Vehicle_Id";
            // 
            // labelRnteddate
            // 
            this.labelRnteddate.AutoSize = true;
            this.labelRnteddate.BackColor = System.Drawing.Color.Transparent;
            this.labelRnteddate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRnteddate.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRnteddate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelRnteddate.Location = new System.Drawing.Point(40, 476);
            this.labelRnteddate.Name = "labelRnteddate";
            this.labelRnteddate.Size = new System.Drawing.Size(119, 24);
            this.labelRnteddate.TabIndex = 39;
            this.labelRnteddate.Text = "Rented_Date";
            // 
            // labeldriver
            // 
            this.labeldriver.AutoSize = true;
            this.labeldriver.BackColor = System.Drawing.Color.Transparent;
            this.labeldriver.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labeldriver.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldriver.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labeldriver.Location = new System.Drawing.Point(40, 417);
            this.labeldriver.Name = "labeldriver";
            this.labeldriver.Size = new System.Drawing.Size(65, 24);
            this.labeldriver.TabIndex = 40;
            this.labeldriver.Text = "Driver";
            // 
            // labelrtrndate
            // 
            this.labelrtrndate.AutoSize = true;
            this.labelrtrndate.BackColor = System.Drawing.Color.Transparent;
            this.labelrtrndate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelrtrndate.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelrtrndate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelrtrndate.Location = new System.Drawing.Point(38, 532);
            this.labelrtrndate.Name = "labelrtrndate";
            this.labelrtrndate.Size = new System.Drawing.Size(137, 24);
            this.labelrtrndate.TabIndex = 41;
            this.labelrtrndate.Text = "Returned_Date";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.BackColor = System.Drawing.Color.Transparent;
            this.lblcustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcustomer.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblcustomer.Location = new System.Drawing.Point(40, 148);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(145, 24);
            this.lblcustomer.TabIndex = 43;
            this.lblcustomer.Text = "Customer Name";
            // 
            // lblnmber
            // 
            this.lblnmber.AutoSize = true;
            this.lblnmber.BackColor = System.Drawing.Color.Transparent;
            this.lblnmber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblnmber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnmber.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lblnmber.Location = new System.Drawing.Point(38, 205);
            this.lblnmber.Name = "lblnmber";
            this.lblnmber.Size = new System.Drawing.Size(134, 24);
            this.lblnmber.TabIndex = 44;
            this.lblnmber.Text = "Phone Number";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.btncalculate);
            this.panel1.Controls.Add(this.txtbxtotal);
            this.panel1.Controls.Add(this.txtbxdrvrtotal);
            this.panel1.Controls.Add(this.txtbxvhclpay);
            this.panel1.Controls.Add(this.Total);
            this.panel1.Controls.Add(this.labeldvr);
            this.panel1.Controls.Add(this.labelvhcl);
            this.panel1.Location = new System.Drawing.Point(838, 92);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(447, 341);
            this.panel1.TabIndex = 47;
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.DarkRed;
            this.btncalculate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.ForeColor = System.Drawing.SystemColors.Control;
            this.btncalculate.Location = new System.Drawing.Point(181, 284);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(129, 40);
            this.btncalculate.TabIndex = 1;
            this.btncalculate.Text = "Calculate";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // txtbxtotal
            // 
            this.txtbxtotal.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxtotal.Location = new System.Drawing.Point(256, 189);
            this.txtbxtotal.Multiline = true;
            this.txtbxtotal.Name = "txtbxtotal";
            this.txtbxtotal.ReadOnly = true;
            this.txtbxtotal.Size = new System.Drawing.Size(180, 37);
            this.txtbxtotal.TabIndex = 52;
            this.txtbxtotal.Text = "0.00";
            // 
            // txtbxdrvrtotal
            // 
            this.txtbxdrvrtotal.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxdrvrtotal.Location = new System.Drawing.Point(256, 126);
            this.txtbxdrvrtotal.Multiline = true;
            this.txtbxdrvrtotal.Name = "txtbxdrvrtotal";
            this.txtbxdrvrtotal.ReadOnly = true;
            this.txtbxdrvrtotal.Size = new System.Drawing.Size(180, 37);
            this.txtbxdrvrtotal.TabIndex = 51;
            this.txtbxdrvrtotal.Text = "0.00";
            // 
            // txtbxvhclpay
            // 
            this.txtbxvhclpay.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxvhclpay.Location = new System.Drawing.Point(256, 56);
            this.txtbxvhclpay.Multiline = true;
            this.txtbxvhclpay.Name = "txtbxvhclpay";
            this.txtbxvhclpay.ReadOnly = true;
            this.txtbxvhclpay.Size = new System.Drawing.Size(180, 37);
            this.txtbxvhclpay.TabIndex = 50;
            this.txtbxvhclpay.Text = "0.00";
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.BackColor = System.Drawing.Color.Transparent;
            this.Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Total.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Total.Location = new System.Drawing.Point(25, 192);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(55, 25);
            this.Total.TabIndex = 49;
            this.Total.Text = "Total";
            // 
            // labeldvr
            // 
            this.labeldvr.AutoSize = true;
            this.labeldvr.BackColor = System.Drawing.Color.Transparent;
            this.labeldvr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labeldvr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldvr.ForeColor = System.Drawing.SystemColors.MenuText;
            this.labeldvr.Location = new System.Drawing.Point(25, 129);
            this.labeldvr.Name = "labeldvr";
            this.labeldvr.Size = new System.Drawing.Size(146, 25);
            this.labeldvr.TabIndex = 48;
            this.labeldvr.Text = "Driver Payment";
            // 
            // labelvhcl
            // 
            this.labelvhcl.AutoSize = true;
            this.labelvhcl.BackColor = System.Drawing.Color.Transparent;
            this.labelvhcl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelvhcl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelvhcl.ForeColor = System.Drawing.SystemColors.MenuText;
            this.labelvhcl.Location = new System.Drawing.Point(25, 59);
            this.labelvhcl.Name = "labelvhcl";
            this.labelvhcl.Size = new System.Drawing.Size(152, 25);
            this.labelvhcl.TabIndex = 47;
            this.labelvhcl.Text = "Vehicle Payment";
            // 
            // txtbxrentid
            // 
            this.txtbxrentid.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxrentid.Location = new System.Drawing.Point(252, 90);
            this.txtbxrentid.Multiline = true;
            this.txtbxrentid.Name = "txtbxrentid";
            this.txtbxrentid.Size = new System.Drawing.Size(180, 37);
            this.txtbxrentid.TabIndex = 48;
            // 
            // txtcustomer
            // 
            this.txtcustomer.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.Location = new System.Drawing.Point(251, 146);
            this.txtcustomer.Multiline = true;
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(180, 40);
            this.txtcustomer.TabIndex = 49;
            // 
            // txtbnumber
            // 
            this.txtbnumber.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbnumber.Location = new System.Drawing.Point(251, 206);
            this.txtbnumber.Multiline = true;
            this.txtbnumber.Name = "txtbnumber";
            this.txtbnumber.Size = new System.Drawing.Size(180, 37);
            this.txtbnumber.TabIndex = 50;
            // 
            // btnhme
            // 
            this.btnhme.BackColor = System.Drawing.Color.DarkRed;
            this.btnhme.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhme.ForeColor = System.Drawing.SystemColors.Control;
            this.btnhme.Location = new System.Drawing.Point(1157, 21);
            this.btnhme.Name = "btnhme";
            this.btnhme.Size = new System.Drawing.Size(111, 40);
            this.btnhme.TabIndex = 8;
            this.btnhme.Text = "Home";
            this.btnhme.UseVisualStyleBackColor = false;
            this.btnhme.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // bbtnclear
            // 
            this.bbtnclear.BackColor = System.Drawing.Color.DarkRed;
            this.bbtnclear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbtnclear.ForeColor = System.Drawing.SystemColors.Control;
            this.bbtnclear.Location = new System.Drawing.Point(615, 746);
            this.bbtnclear.Name = "bbtnclear";
            this.bbtnclear.Size = new System.Drawing.Size(112, 40);
            this.bbtnclear.TabIndex = 57;
            this.bbtnclear.Text = "Clear";
            this.bbtnclear.UseVisualStyleBackColor = false;
            this.bbtnclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(775, 439);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(510, 290);
            this.pictureBox1.TabIndex = 58;
            this.pictureBox1.TabStop = false;
            // 
            // rad_rentdriver
            // 
            this.rad_rentdriver.AutoSize = true;
            this.rad_rentdriver.BackColor = System.Drawing.Color.DarkRed;
            this.rad_rentdriver.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_rentdriver.ForeColor = System.Drawing.SystemColors.Control;
            this.rad_rentdriver.Location = new System.Drawing.Point(250, 405);
            this.rad_rentdriver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rad_rentdriver.Name = "rad_rentdriver";
            this.rad_rentdriver.Size = new System.Drawing.Size(133, 21);
            this.rad_rentdriver.TabIndex = 60;
            this.rad_rentdriver.Text = "Rent with Driver";
            this.rad_rentdriver.UseVisualStyleBackColor = false;
            // 
            // rad_rent
            // 
            this.rad_rent.AutoSize = true;
            this.rad_rent.BackColor = System.Drawing.Color.DarkRed;
            this.rad_rent.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_rent.ForeColor = System.Drawing.SystemColors.Control;
            this.rad_rent.Location = new System.Drawing.Point(251, 434);
            this.rad_rent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rad_rent.Name = "rad_rent";
            this.rad_rent.Size = new System.Drawing.Size(153, 21);
            this.rad_rent.TabIndex = 59;
            this.rad_rent.Text = "Rent without Driver";
            this.rad_rent.UseVisualStyleBackColor = false;
            this.rad_rent.CheckedChanged += new System.EventHandler(this.rad_rent_CheckedChanged);
            // 
            // cmdvehicle
            // 
            this.cmdvehicle.FormattingEnabled = true;
            this.cmdvehicle.Location = new System.Drawing.Point(252, 362);
            this.cmdvehicle.Name = "cmdvehicle";
            this.cmdvehicle.Size = new System.Drawing.Size(180, 24);
            this.cmdvehicle.TabIndex = 61;
            // 
            // dtprented
            // 
            this.dtprented.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtprented.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtprented.Location = new System.Drawing.Point(252, 474);
            this.dtprented.Name = "dtprented";
            this.dtprented.Size = new System.Drawing.Size(180, 28);
            this.dtprented.TabIndex = 62;
            // 
            // dtpreturn
            // 
            this.dtpreturn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpreturn.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpreturn.Location = new System.Drawing.Point(250, 532);
            this.dtpreturn.Name = "dtpreturn";
            this.dtpreturn.Size = new System.Drawing.Size(181, 28);
            this.dtpreturn.TabIndex = 63;
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkRed;
            this.btnview.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.SystemColors.Control;
            this.btnview.Location = new System.Drawing.Point(754, 745);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(112, 40);
            this.btnview.TabIndex = 64;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(775, 439);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(510, 290);
            this.dataGridView1.TabIndex = 66;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1297, 808);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dtpreturn);
            this.Controls.Add(this.dtprented);
            this.Controls.Add(this.cmdvehicle);
            this.Controls.Add(this.rad_rentdriver);
            this.Controls.Add(this.rad_rent);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bbtnclear);
            this.Controls.Add(this.btnhme);
            this.Controls.Add(this.txtbnumber);
            this.Controls.Add(this.txtcustomer);
            this.Controls.Add(this.txtbxrentid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblnmber);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.labelrtrndate);
            this.Controls.Add(this.labeldriver);
            this.Controls.Add(this.labelRnteddate);
            this.Controls.Add(this.labelvehicle);
            this.Controls.Add(this.labelrntid);
            this.Controls.Add(this.srchbtn);
            this.Controls.Add(this.dltbtn);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.savebtn);
            this.Controls.Add(this.extbtn);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rent";
            this.Load += new System.EventHandler(this.Form5_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button extbtn;
        private System.Windows.Forms.Button srchbtn;
        private System.Windows.Forms.Button dltbtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button savebtn;
        private System.Windows.Forms.Label labelrntid;
        private System.Windows.Forms.Label labelvehicle;
        private System.Windows.Forms.Label labelRnteddate;
        private System.Windows.Forms.Label labeldriver;
        private System.Windows.Forms.Label labelrtrndate;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblnmber;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label labeldvr;
        private System.Windows.Forms.Label labelvhcl;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.TextBox txtbxtotal;
        private System.Windows.Forms.TextBox txtbxdrvrtotal;
        private System.Windows.Forms.TextBox txtbxvhclpay;
        private System.Windows.Forms.TextBox txtbxrentid;
        private System.Windows.Forms.TextBox txtcustomer;
        private System.Windows.Forms.TextBox txtbnumber;
        private System.Windows.Forms.Button btnhme;
        private System.Windows.Forms.Button bbtnclear;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton rad_rentdriver;
        private System.Windows.Forms.RadioButton rad_rent;
        private System.Windows.Forms.ComboBox cmdvehicle;
        private System.Windows.Forms.DateTimePicker dtprented;
        private System.Windows.Forms.DateTimePicker dtpreturn;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}