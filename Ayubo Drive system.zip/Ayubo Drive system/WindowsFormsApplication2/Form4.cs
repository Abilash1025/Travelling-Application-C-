﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class Form4 : Form
    {
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=Ayubo;Integrated Security=True";
        int id, passengers, dayrent, weekrent, monthrent, hundredkm, twohundredkm, threehundredkm, fourhundredkm, foronekm, extrakm, driver, waiting;
        string name, type, color;
        SqlDataAdapter chart;
        DataTable dt;

        SqlConnection con = new SqlConnection(connection);


        public Form4()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void srchbtn_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                id = int.Parse(txtid.Text);
                string search = "Select *from Table_ADD1 where V_id='" + id + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();

                if (r.Read())
                {
                    txttype.Text = r["V_type"].ToString();
                    txtname.Text = r["V_Name"].ToString();
                    txtcolor.Text = r["V_Color"].ToString();
                    txtpassesngers.Text = r["V_passengers"].ToString();
                    txtdayrent.Text = r["Day_rent"].ToString();
                    txtweekrent.Text = r["Week_rent"].ToString();
                    txtmonthrent.Text = r["Month_rent"].ToString();
                    txt100.Text = r["Hundredkm"].ToString();
                    txt200.Text = r["twohundredkm"].ToString();
                    txt300.Text = r["threehundredkm"].ToString();
                    txt400.Text = r["fourhundredkm"].ToString();
                    txt1km.Text = r["Km_charge"].ToString();
                    txtextrakm.Text = r["Extrakm_charge"].ToString();
                    txtdriver.Text = r["Driver_charge"].ToString();
                    txtwaiting.Text = r["waiting_charge"].ToString();
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Invalid Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);



                }
            }
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                id = int.Parse(txtid.Text);
                type = txttype.Text;
                name = txtname.Text;
                color = txtcolor.Text;
                passengers = int.Parse(txtpassesngers.Text);
                dayrent = int.Parse(txtdayrent.Text);
                weekrent = int.Parse(txtweekrent.Text);
                monthrent = int.Parse(txtmonthrent.Text);
                hundredkm = int.Parse(txt100.Text);
                twohundredkm = int.Parse(txt200.Text);
                threehundredkm = int.Parse(txt300.Text);
                fourhundredkm = int.Parse(txt400.Text);
                foronekm = int.Parse(txt1km.Text);
                extrakm = int.Parse(txtextrakm.Text);
                driver = int.Parse(txtdriver.Text);
                waiting = int.Parse(txtwaiting.Text);

                con.Open();

                string insert = "insert into Table_ADD1 values('" + id + "','" + type + "','" + name + "','" + color + "','" + passengers + "','" +
                    dayrent + "','" + weekrent + "','" + monthrent + "','" + hundredkm + "','" + twohundredkm + "','" + threehundredkm + "','" +
                    fourhundredkm + "','" + foronekm + "','" + extrakm + "','" + driver + "','" + waiting + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();



                MessageBox.Show("Successfully Added", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();





            }
        }
        private void clearbtn_Click(object sender, EventArgs e)
        {

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {

                id = int.Parse(txtid.Text);
                string type = txttype.Text;
                string name = txtname.Text;
                string color = txtcolor.Text;
                passengers = int.Parse(txtpassesngers.Text);
                dayrent = int.Parse(txtdayrent.Text);
                weekrent = int.Parse(txtweekrent.Text);
                monthrent = int.Parse(txtmonthrent.Text);
                hundredkm = int.Parse(txt100.Text);
                twohundredkm = int.Parse(txt200.Text);
                threehundredkm = int.Parse(txt300.Text);
                fourhundredkm = int.Parse(txt400.Text);
                foronekm = int.Parse(txt1km.Text);
                extrakm = int.Parse(txtextrakm.Text);
                driver = int.Parse(txtdriver.Text);
                waiting = int.Parse(txtwaiting.Text);

                string update = "update Table_ADD1 set V_type = '" + type + "', V_name = '" + name + "', V_color = '" + color + "', V_passengers = '" + passengers + "', Day_rent = '" +
                    dayrent + "', Week_rent = '" + weekrent + "', Month_rent = '" + monthrent + "', Hundredkm = '" + hundredkm + "', twohundredkm = '" +
                    twohundredkm + "', threehundredkm = '" + threehundredkm + "', fourhundredkm = '" + fourhundredkm + "', Km_charge = '" + foronekm + "', Extrakm_charge = '" +
                    extrakm + "', Driver_charge = '" + driver + "', waiting_charge = '" + waiting + "' where V_id = '" + id + "'";
                if (MessageBox.Show("Are you going to update?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated");
                    con.Close();


                }
            }
        }
        private void dltbtn_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "")
            {
                MessageBox.Show("Please enter the id");
            }
            else
            {
                string delete = "Delete from Table_ADD1 where V_id = '" + id + "' ";
                SqlCommand cmd = new SqlCommand(delete, con);

                if (MessageBox.Show("Are you want to delete a existing record?", "confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Deleted Succesfully", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();


                }
            }
        }
       

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtid.Clear();
            txtname.Clear();
            txttype.Clear();
            txtcolor.Clear();
            txtpassesngers.Clear();
            txtdayrent.Clear();
            txtweekrent.Clear();
            txtmonthrent.Clear();
            txt100.Clear();
            txt200.Clear();
            txt300.Clear();
            txt400.Clear();
            txt1km.Clear();
            txtextrakm.Clear();
            txtdriver.Clear();
            txtwaiting.Clear();
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            chart = new SqlDataAdapter("Select * from Table_ADD1 ", con);
            dt = new DataTable();
            chart.Fill(dt);
            dataGridView1.DataSource = dt;

            pictureBox1.Visible = false;
            dataGridView1.Visible = true;

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
    }
}

